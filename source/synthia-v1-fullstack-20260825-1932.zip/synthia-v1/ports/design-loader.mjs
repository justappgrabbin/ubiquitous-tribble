/**
 * Real Design input loader.
 * Accepts Human Design / chart-style seeds and maps to the locked address schema:
 * Planetary → Dimension → Gate → Line → Color → Tone → Base
 * → Degree → Minute → Second → Arc → Zodiac → House
 *
 * Public layers may be shared; sub-base stays private.
 */

const DIMENSIONS = ['Movement', 'Evolution', 'Being', 'Design', 'Space'];
const PLANETS = [
  'Sun', 'Earth', 'Moon', 'NorthNode', 'SouthNode',
  'Mercury', 'Venus', 'Mars', 'Jupiter', 'Saturn',
  'Uranus', 'Neptune', 'Pluto',
];

/**
 * Normalize a chart seed into full Design + private sub-base.
 * Accepts partial charts; fills deterministically from available fields.
 */
export function loadDesignFromChart(chart = {}) {
  // Personality / Design Sun is the primary gate anchor when present
  const sun =
    chart.design?.sun ||
    chart.personality?.sun ||
    chart.sun ||
    { gate: chart.gate ?? 20, line: chart.line ?? 3 };

  const gate = clampInt(sun.gate ?? chart.gate ?? 20, 1, 64);
  const line = clampInt(sun.line ?? chart.line ?? 3, 1, 6);
  const color = clampInt(sun.color ?? chart.color ?? 1, 1, 6);
  const tone = clampInt(sun.tone ?? chart.tone ?? 1, 1, 6);
  const base = clampInt(sun.base ?? chart.base ?? 1, 1, 5);

  const dimension =
    chart.dimension ||
    DIMENSIONS[Math.abs(hash(`${gate}-${line}`)) % DIMENSIONS.length];

  const planetary = chart.planetary || chart.planet || 'Sun';
  const zodiac = clampInt(chart.zodiac ?? sun.signIndex ?? ((gate - 1) % 12) + 1, 1, 12);
  const house = clampInt(chart.house ?? sun.house ?? ((gate - 1) % 12) + 1, 1, 12);

  // Sub-base: private. Prefer explicit; else derive deterministically (not random).
  const subSeed = hash([gate, line, color, tone, base, chart.name || ''].join('|'));
  const degree = chart.degree ?? (subSeed % 30);
  const minute = chart.minute ?? ((subSeed >>> 5) % 60);
  const second = chart.second ?? ((subSeed >>> 11) % 60);
  const arc = chart.arc ?? ((subSeed >>> 17) % 3600) / 10;

  const chronotype =
    chart.chronotype != null
      ? Math.max(-1, Math.min(1, chart.chronotype))
      : ((line - 3.5) / 3.5) * 0.8; // line bias → mild chrono lean

  const design = {
    planetary,
    dimension,
    gate,
    line,
    color,
    tone,
    base,
    degree,
    minute,
    second,
    arc,
    zodiac,
    house,
    chronotype,
    name: chart.name || chart.label || null,
    type: chart.type || null,
    profile: chart.profile || (line ? `${line}/${((line % 6) + 1)}` : null),
    authority: chart.authority || null,
    definition: chart.definition || null,
    // public identity key (excludes sub-base)
    addressKey: [planetary, dimension, gate, line, color, tone, base, zodiac, house].join('|'),
    // private key for same-position mesh share only
    privateKey: [degree, minute, second, arc].join('|'),
  };

  return design;
}

/**
 * Sample / demo chart — not a real person; structure matches HD chart exports.
 */
export function sampleChart(overrides = {}) {
  return loadDesignFromChart({
    name: overrides.name || 'Demo Design',
    type: 'Generator',
    profile: '3/5',
    authority: 'Sacral',
    definition: 'Single',
    design: {
      sun: {
        gate: overrides.gate ?? 20,
        line: overrides.line ?? 3,
        color: overrides.color ?? 2,
        tone: overrides.tone ?? 1,
        base: overrides.base ?? 4,
      },
    },
    personality: {
      sun: {
        gate: overrides.pGate ?? 34,
        line: overrides.pLine ?? 1,
      },
    },
    dimension: overrides.dimension || 'Design',
    planetary: 'Sun',
    ...overrides,
  });
}

function clampInt(n, lo, hi) {
  const x = parseInt(n, 10);
  if (Number.isNaN(x)) return lo;
  return Math.max(lo, Math.min(hi, x));
}

function hash(s) {
  let h = 2166136261;
  const str = String(s);
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

export { DIMENSIONS, PLANETS };
