/**
 * Node/ESM bridge to the real ToolFactory in toolfactory-core.js.
 * Loads the factory, exposes generateFromAddress so personIngest can
 * produce person-unique executable tools bound to Design + content address.
 */

import { readFileSync } from 'fs';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __dirname = dirname(fileURLToPath(import.meta.url));
const corePath = join(__dirname, '..', 'toolfactory-core.js');

// Load the non-module core in a sandbox that supplies what it needs.
const coreSource = readFileSync(corePath, 'utf8');

// Minimal globals the core expects
const sandbox = {
  crypto: {
    randomUUID: () =>
      'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
        const r = (Math.random() * 16) | 0;
        const v = c === 'x' ? r : (r & 0x3) | 0x8;
        return v.toString(16);
      }),
  },
  console,
  Math,
  Date,
  Map,
  Set,
  Object,
  Array,
  String,
  Number,
  JSON,
  Float32Array,
  parseInt,
  isNaN,
};

// The core file defines classes/consts in global scope when eval'd.
// We capture ToolFactory + BY_KW_NUM + BY_KW after evaluation.
const capture = `
${coreSource}
return {
  ToolFactory: typeof ToolFactory !== 'undefined' ? ToolFactory : null,
  BY_KW_NUM: typeof BY_KW_NUM !== 'undefined' ? BY_KW_NUM : null,
  BY_KW: typeof BY_KW !== 'undefined' ? BY_KW : null,
  BY_FUXI: typeof BY_FUXI !== 'undefined' ? BY_FUXI : null,
  TF_LEVELS: typeof TF_LEVELS !== 'undefined' ? TF_LEVELS : null,
  HEXAGRAMS: typeof HEXAGRAMS !== 'undefined' ? HEXAGRAMS : null,
};
`;

let factoryApi;
try {
  // Function constructor with sandbox bindings
  const keys = Object.keys(sandbox);
  const vals = keys.map((k) => sandbox[k]);
  factoryApi = new Function(...keys, capture)(...vals);
} catch (e) {
  factoryApi = { error: e.message, ToolFactory: null };
}

export function isToolFactoryReady() {
  return !!(factoryApi && factoryApi.ToolFactory);
}

export function getFactoryApi() {
  return factoryApi;
}

/**
 * Generate a ToolFactory tool from a canonical Synthia address + optional changing line.
 * Event shape expected by real ToolFactory:
 *   { fromFuxi, toFuxi, changingLines: [{ lineNumber }] }
 */
export function generateFromAddress(canonical, opts = {}) {
  if (!factoryApi?.ToolFactory || !factoryApi?.BY_KW_NUM) {
    return {
      error: factoryApi?.error || 'ToolFactory not loaded',
      ready: false,
    };
  }

  const gateNum = canonical.gate; // 1-64
  const hex = factoryApi.BY_KW_NUM[gateNum];
  if (!hex) {
    return { error: `No hexagram for gate ${gateNum}`, ready: true };
  }

  const fromFuxi = hex.fuxi;
  const toFuxi =
    opts.toFuxi != null
      ? opts.toFuxi
      : hex.complement != null
        ? hex.complement
        : fromFuxi ^ 63;

  const lineNumber = opts.lineNumber ?? canonical.line ?? 1;

  const tf = new factoryApi.ToolFactory();
  const event = {
    fromFuxi,
    toFuxi,
    changingLines: [{ lineNumber }],
  };

  const generated = tf.generate(event);

  return {
    ready: true,
    designKey: canonical.key,
    gate: gateNum,
    event,
    generated, // { id, name, level, levelName, address, code, liveResult }
    stats: tf.getStats(),
  };
}
