/**
 * Pure JS port of Dunbar-layer social structure from one-sim npcs.py.
 * ~5 intimate + ~15 close + ~50 meaningful + ~150 active.
 * Weak-tie gossip pathway (Granovetter). Deterministic structure; no RNG required for layer assignment.
 */

export const LAYERS = Object.freeze({
  intimate: { max: 5, label: 'intimate' },
  close: { max: 15, label: 'close' },
  meaningful: { max: 50, label: 'meaningful' },
  active: { max: 150, label: 'active' },
});

/**
 * Rank a contact by affinity score into a Dunbar layer.
 * affinity ∈ [0,1]
 */
export function layerForAffinity(affinity) {
  const a = Math.max(0, Math.min(1, affinity));
  if (a >= 0.85) return 'intimate';
  if (a >= 0.65) return 'close';
  if (a >= 0.4) return 'meaningful';
  if (a >= 0.15) return 'active';
  return 'peripheral';
}

/**
 * Create a social graph bound to a Design (person-unique).
 */
export function createSocialGraph(design = {}) {
  return {
    contacts: Object.create(null), // mid -> { mid, name, affinity, layer, lastTouch }
    designKey: design.addressKey || null,
  };
}

export function upsertContact(graph, mid, name, affinity, tick = 0) {
  const layer = layerForAffinity(affinity);
  graph.contacts[mid] = {
    mid,
    name,
    affinity: Math.max(0, Math.min(1, affinity)),
    layer,
    lastTouch: tick,
  };
  return graph.contacts[mid];
}

/**
 * Decay affinity over time (weak ties decay faster).
 */
export function decayContact(graph, mid, dtDays = 1) {
  const c = graph.contacts[mid];
  if (!c) return null;
  const rate = c.layer === 'intimate' ? 0.002
    : c.layer === 'close' ? 0.006
    : c.layer === 'meaningful' ? 0.012
    : 0.025;
  c.affinity = Math.max(0, c.affinity - rate * dtDays);
  c.layer = layerForAffinity(c.affinity);
  return c;
}

/**
 * Weak-tie bridge candidates: active/peripheral contacts that can carry news.
 */
export function weakTieBridges(graph) {
  return Object.values(graph.contacts).filter(
    (c) => c.layer === 'active' || c.layer === 'peripheral' || c.layer === 'meaningful'
  );
}

/**
 * Count per layer (for mesh diagnostics).
 */
export function layerCounts(graph) {
  const counts = { intimate: 0, close: 0, meaningful: 0, active: 0, peripheral: 0 };
  for (const c of Object.values(graph.contacts)) {
    counts[c.layer] = (counts[c.layer] || 0) + 1;
  }
  return counts;
}
