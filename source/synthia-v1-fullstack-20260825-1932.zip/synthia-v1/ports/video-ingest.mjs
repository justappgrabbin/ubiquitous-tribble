/**
 * Video / frame-sequence → address → runnable artifact.
 * Accepts PPM paths, frame descriptor arrays, or {width,height,frames:[{rgb|rgba}]} .
 * Same Design + same content → same tool (via personIngest identity rule).
 */

import { readFileSync, existsSync } from 'fs';

/**
 * Parse a binary PPM (P6) into { width, height, rgb: Uint8Array }.
 */
export function parsePPM(buf) {
  const data = Buffer.isBuffer(buf) ? buf : Buffer.from(buf);
  let offset = 0;
  const readLine = () => {
    let s = '';
    while (offset < data.length) {
      const c = data[offset++];
      if (c === 0x0a) break;
      if (c !== 0x0d) s += String.fromCharCode(c);
    }
    return s.trim();
  };
  const magic = readLine();
  if (magic !== 'P6') throw new Error(`Not P6 PPM: ${magic}`);
  let line = readLine();
  while (line.startsWith('#')) line = readLine();
  const [w, h] = line.split(/\s+/).map(Number);
  const maxval = Number(readLine());
  if (maxval !== 255) throw new Error(`Unsupported maxval ${maxval}`);
  const rgb = data.subarray(offset, offset + w * h * 3);
  return { width: w, height: h, rgb };
}

/**
 * Fingerprint content of frames for stable contentKey.
 */
export function fingerprintFrames(frames) {
  let h = 2166136261;
  for (const f of frames) {
    const w = f.width || 0;
    const hgt = f.height || 0;
    h ^= w;
    h = Math.imul(h, 16777619);
    h ^= hgt;
    h = Math.imul(h, 16777619);
    if (f.rgb) {
      const arr = f.rgb;
      const step = Math.max(1, Math.floor(arr.length / 64));
      for (let i = 0; i < arr.length; i += step) {
        h ^= arr[i];
        h = Math.imul(h, 16777619);
      }
    } else if (f.r != null) {
      h ^= (f.r << 16) ^ (f.g << 8) ^ f.b;
      h = Math.imul(h, 16777619);
    }
  }
  return (h >>> 0).toString(16);
}

/**
 * Build an ingestable content object from video/frames.
 */
export function framesToContent(frames, meta = {}) {
  const fp = fingerprintFrames(frames);
  const summary = {
    kind: 'video-frames',
    frameCount: frames.length,
    width: frames[0]?.width || meta.width || 0,
    height: frames[0]?.height || meta.height || 0,
    fingerprint: fp,
    name: meta.name || `video-${fp}`,
  };
  // Textual surface for address hashing + quality attribution
  const text = [
    summary.name,
    `frames:${summary.frameCount}`,
    `size:${summary.width}x${summary.height}`,
    `fp:${fp}`,
    meta.description || '',
  ].join(' ');
  return {
    kind: 'video-frames',
    text,
    summary,
    frames: frames.map((f, i) => ({
      index: i,
      width: f.width,
      height: f.height,
      // keep small rgb sample for primitive, not full buffers in address path
      sample: f.rgb
        ? Array.from(f.rgb.subarray(0, Math.min(12, f.rgb.length)))
        : [f.r ?? 0, f.g ?? 0, f.b ?? 0],
    })),
  };
}

/**
 * Load PPM files from disk into frames.
 */
export function loadPPMSequence(paths) {
  return paths.filter((p) => existsSync(p)).map((p) => {
    const parsed = parsePPM(readFileSync(p));
    return { ...parsed, path: p };
  });
}

/**
 * High-level: paths or frame array → content object ready for personIngest.
 */
export function prepareVideoIngest(input, meta = {}) {
  let frames;
  if (Array.isArray(input) && typeof input[0] === 'string') {
    frames = loadPPMSequence(input);
  } else if (Array.isArray(input)) {
    frames = input;
  } else {
    throw new Error('prepareVideoIngest expects path[] or frame[]');
  }
  if (!frames.length) throw new Error('no frames');
  return framesToContent(frames, meta);
}
