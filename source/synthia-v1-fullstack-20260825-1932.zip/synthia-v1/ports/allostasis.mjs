/**
 * Pure JS port of one-sim allostasis (McEwen & Stellar style load).
 * Sustained stress accumulates as standing wear; heals slowly.
 * Deterministic. Bound to Design when used by Synthia.
 */

export const DEFAULT_LOAD = 0.15;
export const ACCRUE_RATE = 0.002;   // per stress-minute equivalent
export const HEAL_RATE = 0.0008;    // per calm-minute
export const ILLNESS_THRESHOLD = 0.78;

/**
 * @param {number} load [0,1]
 * @param {number} stressSignal [0,1] current stress intensity
 * @param {number} dtMinutes
 */
export function stepLoad(load, stressSignal, dtMinutes = 1) {
  let L = Math.max(0, Math.min(1, load));
  const stress = Math.max(0, Math.min(1, stressSignal));
  const dt = Math.max(0, dtMinutes);
  if (stress > 0.25) {
    L += ACCRUE_RATE * stress * dt;
  } else {
    L -= HEAL_RATE * (1 - stress) * dt;
  }
  return Math.max(0, Math.min(1, L));
}

export function illnessRisk(load) {
  if (load < ILLNESS_THRESHOLD) return 0;
  return Math.min(1, (load - ILLNESS_THRESHOLD) / (1 - ILLNESS_THRESHOLD));
}

export function createAllostasisState(design = {}) {
  return {
    load: DEFAULT_LOAD,
    designKey: design.addressKey || null,
  };
}

export function tickAllostasis(state, stressSignal = 0, dtMinutes = 1) {
  const load = stepLoad(state.load, stressSignal, dtMinutes);
  return {
    ...state,
    load,
    risk: illnessRisk(load),
    band: load < 0.3 ? 'resilient' : load < 0.55 ? 'loaded' : load < ILLNESS_THRESHOLD ? 'strained' : 'high-risk',
  };
}
