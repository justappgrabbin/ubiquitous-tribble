/**
 * Pure JS port of alters-lab core: snapshot, reality score, resolution, rubric.
 * Bound to Design address. Sub-base fields stay private (never public).
 * Same Design + same content → same alter identity path.
 */

const RUBRIC_DIMENSIONS = Object.freeze([
  { name: 'execution_discipline', weight: 0.25 },
  { name: 'exploration_freedom', weight: 0.25 },
  { name: 'life_state_match', weight: 0.25 },
  { name: 'energy_level', weight: 0.25 },
]);

/**
 * Create an alter bound to a person Design (public layers only in public view).
 * Private sub-base (degree/minute/second/arc) stored but never exported publicly.
 */
export function createAlter(design, meta = {}) {
  const publicAddress = {
    planetary: design.planetary ?? null,
    dimension: design.dimension ?? null,
    gate: design.gate ?? null,
    line: design.line ?? null,
    color: design.color ?? null,
    tone: design.tone ?? null,
    base: design.base ?? null,
    zodiac: design.zodiac ?? null,
    house: design.house ?? null,
  };
  const privateSubBase = {
    degree: design.degree ?? null,
    minute: design.minute ?? null,
    second: design.second ?? null,
    arc: design.arc ?? null,
  };
  return {
    id: meta.id || `alter-${publicAddress.gate || 0}-${publicAddress.line || 0}`,
    publicAddress,
    // private — only for Synthia + same-position mesh
    _private: privateSubBase,
    anchors: {
      heaviest_constraint: meta.heaviest_constraint || '',
      most_unclear: meta.most_unclear || '',
      unwilling_to_give_up: meta.unwilling_to_give_up || '',
    },
    context: {
      current_commitments: meta.commitments || [],
      external_deadlines: meta.deadlines || [],
      energy_state: meta.energy_state || '',
    },
    predicted: {
      execution_discipline: meta.predicted?.execution_discipline ?? 3,
      exploration_freedom: meta.predicted?.exploration_freedom ?? 3,
      life_state_match: meta.predicted?.life_state_match ?? 3,
      energy_level: meta.predicted?.energy_level ?? 3,
    },
    status: 'active',
    version: 1,
  };
}

/**
 * Public view of an alter — strips _private sub-base.
 */
export function publicView(alter) {
  const { _private, ...rest } = alter;
  return rest;
}

/**
 * Reality drift vs actual scores (1-5 each dimension).
 * Mean absolute normalised drift.
 */
export function realityDrift(alter, actual) {
  let sum = 0;
  for (const d of RUBRIC_DIMENSIONS) {
    const p = alter.predicted[d.name] ?? 3;
    const a = actual[d.name] ?? 3;
    sum += Math.abs(p - a) / 4;
  }
  return sum / RUBRIC_DIMENSIONS.length;
}

/**
 * Snapshot (faithful, append-only archive entry).
 */
export function snapshotAlter(alter, archiveId, notes = []) {
  return Object.freeze({
    archive_id: archiveId,
    date: new Date().toISOString(),
    version: alter.version,
    status: 'archived',
    publicAddress: { ...alter.publicAddress },
    // private sub-base archived for Synthia only — not for public export
    _private: { ...alter._private },
    anchors: { ...alter.anchors },
    context: {
      current_commitments: [...(alter.context.current_commitments || [])],
      external_deadlines: [...(alter.context.external_deadlines || [])],
      energy_state: alter.context.energy_state,
    },
    predicted: { ...alter.predicted },
    notes: [...notes],
  });
}

/**
 * Mesh-shareable gate identity only (weak link).
 * Same gate → latent mesh connection; strength ~1/1e6 until contact.
 */
export function meshGateKey(alter) {
  const g = alter.publicAddress.gate;
  if (g == null) return null;
  return `gate:${g}`;
}

/**
 * Same-position key for private sub-base sharing (must match full public + private).
 */
export function samePositionKey(alter) {
  const p = alter.publicAddress;
  const s = alter._private;
  return [
    p.planetary, p.dimension, p.gate, p.line, p.color, p.tone, p.base,
    s.degree, s.minute, s.second, s.arc,
    p.zodiac, p.house,
  ].join('|');
}
