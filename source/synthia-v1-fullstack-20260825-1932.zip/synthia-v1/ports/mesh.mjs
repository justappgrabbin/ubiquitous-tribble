/**
 * Gate-level mesh: latent weak links by default (~1/1e6).
 * Contact / deliberate pull raises strength.
 * Private sub-base share only when samePositionKey matches AND strength above threshold.
 */

const LATENT = 1e-6;
const CONTACT_BOOST = 0.08;
const PULL_BOOST = 0.25;
const PRIVATE_SHARE_THRESHOLD = 0.5;

export function createMesh() {
  return {
    // gate -> Set of participant designKeys (public)
    byGate: new Map(),
    // pairKey -> strength 0..1
    edges: new Map(),
    // designKey -> { publicAddress, privateKey }
    nodes: new Map(),
  };
}

function pairKey(a, b) {
  return a < b ? `${a}::${b}` : `${b}::${a}`;
}

export function registerOnMesh(mesh, design) {
  const key = design.addressKey;
  mesh.nodes.set(key, {
    publicAddress: {
      planetary: design.planetary,
      dimension: design.dimension,
      gate: design.gate,
      line: design.line,
      color: design.color,
      tone: design.tone,
      base: design.base,
      zodiac: design.zodiac,
      house: design.house,
    },
    privateKey: design.privateKey,
  });

  const g = design.gate;
  if (!mesh.byGate.has(g)) mesh.byGate.set(g, new Set());
  const peers = mesh.byGate.get(g);
  for (const other of peers) {
    if (other === key) continue;
    const pk = pairKey(key, other);
    if (!mesh.edges.has(pk)) mesh.edges.set(pk, LATENT);
  }
  peers.add(key);
  return { gate: g, peers: peers.size };
}

/** Deliberate contact between two designs (must share gate for latent edge to exist). */
export function contact(mesh, designKeyA, designKeyB) {
  const a = mesh.nodes.get(designKeyA);
  const b = mesh.nodes.get(designKeyB);
  if (!a || !b) return { ok: false, error: 'unknown node' };
  if (a.publicAddress.gate !== b.publicAddress.gate) {
    return { ok: false, error: 'no shared gate — no mesh edge' };
  }
  const pk = pairKey(designKeyA, designKeyB);
  const prev = mesh.edges.get(pk) ?? LATENT;
  const next = Math.min(1, prev + CONTACT_BOOST);
  mesh.edges.set(pk, next);
  return { ok: true, strength: next, sharedGate: a.publicAddress.gate };
}

/** Stronger deliberate pull. */
export function pull(mesh, designKeyA, designKeyB) {
  const base = contact(mesh, designKeyA, designKeyB);
  if (!base.ok) return base;
  const pk = pairKey(designKeyA, designKeyB);
  const next = Math.min(1, (mesh.edges.get(pk) ?? LATENT) + PULL_BOOST);
  mesh.edges.set(pk, next);
  return { ok: true, strength: next, sharedGate: base.sharedGate };
}

/**
 * Attempt private sub-base share.
 * Only if same privateKey (same position) AND edge strength high enough.
 * Otherwise returns public-only view.
 */
export function tryPrivateShare(mesh, designKeyA, designKeyB) {
  const a = mesh.nodes.get(designKeyA);
  const b = mesh.nodes.get(designKeyB);
  if (!a || !b) return { shared: false, reason: 'unknown' };

  const strength = mesh.edges.get(pairKey(designKeyA, designKeyB)) ?? 0;
  const samePosition = a.privateKey && a.privateKey === b.privateKey;

  if (!samePosition) {
    return {
      shared: false,
      reason: 'different position',
      strength,
      publicOnly: true,
      peerPublic: b.publicAddress,
    };
  }
  if (strength < PRIVATE_SHARE_THRESHOLD) {
    return {
      shared: false,
      reason: 'strength below threshold',
      strength,
      need: PRIVATE_SHARE_THRESHOLD,
      publicOnly: true,
      peerPublic: b.publicAddress,
    };
  }
  return {
    shared: true,
    strength,
    peerPublic: b.publicAddress,
    // private sub-base may flow only in this case
    peerPrivateKey: b.privateKey,
  };
}

export function meshSnapshot(mesh) {
  return {
    nodes: mesh.nodes.size,
    gates: [...mesh.byGate.entries()].map(([g, set]) => ({ gate: g, count: set.size })),
    edges: [...mesh.edges.entries()].map(([k, s]) => ({ pair: k, strength: s })),
  };
}

export { LATENT, PRIVATE_SHARE_THRESHOLD };
