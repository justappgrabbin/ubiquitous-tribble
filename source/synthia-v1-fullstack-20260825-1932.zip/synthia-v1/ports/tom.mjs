/**
 * Pure JS port of one-sim Theory-of-Mind / false-belief store (sim/onesim/tom.py).
 * Beliefs are mutable models of the PRESENT, kept outside episodic memory (firewall).
 * Deterministic updates from perception events only. No RNG.
 */

export function moodBand(v) {
  if (v >= 0.2) return 'in good spirits';
  if (v <= -0.2) return 'low';
  return 'much as ever';
}

/**
 * POV has just perceived someone. Update belief; return surprise if false belief corrected.
 * Pure.
 */
export function notePerception(beliefs, mid, name, node, nodeName, mood, fact, tick, day) {
  const prior = beliefs[mid] || null;
  let surprise = null;
  if (prior && prior.where != null && prior.where !== node) {
    surprise = {
      mid,
      name,
      wasWhere: prior.where,
      wasWhereName: prior.whereName || prior.where,
      nowWhere: node,
      nowWhereName: nodeName,
      tick,
      day,
    };
  }
  beliefs[mid] = {
    mid,
    name,
    where: node,
    whereName: nodeName,
    mood: moodBand(typeof mood === 'number' ? mood : 0),
    fact: fact || null,
    lastSeenTick: tick,
    lastSeenDay: day,
  };
  return surprise;
}

/**
 * Read current belief about mid (may be stale / false).
 */
export function beliefAbout(beliefs, mid) {
  return beliefs[mid] || null;
}

/**
 * Create empty belief store bound to a Design address (person-unique).
 */
export function createBeliefStore(design = {}) {
  return {
    beliefs: Object.create(null),
    designKey: design.addressKey || null,
  };
}

/**
 * Apply a batch of perception events. Returns list of surprises.
 */
export function applyPerceptions(store, events) {
  const surprises = [];
  for (const e of events) {
    const s = notePerception(
      store.beliefs,
      e.mid,
      e.name,
      e.node,
      e.nodeName || e.node,
      e.mood ?? 0,
      e.fact ?? null,
      e.tick ?? 0,
      e.day ?? 0
    );
    if (s) surprises.push(s);
  }
  return surprises;
}
