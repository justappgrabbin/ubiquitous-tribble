/**
 * Pure JS port of one-sim Borbély two-process sleep (sim/onesim/sleep.py).
 * Process S (homeostatic pressure) + Process C (circadian).
 * Fully deterministic. No RNG. Bound to Design/address when used by Synthia.
 */

const DAY = 24 * 60; // minutes

// Process S
export const TAU_WAKE = 18 * 60;   // ~18h rise while awake
export const TAU_SLEEP = 4 * 60;   // ~4h fall while asleep
export const DEFAULT_S = 0.35;

// Circadian
const ACROPHASE = 17 * 60;         // 17:00 peak for neutral chronotype
const CHRONO_SHIFT = 90;           // ±90 min for full lark/owl

export const WAKE_EARLIEST = 6 * 60;
export const WAKE_LATEST = 11 * 60;

/**
 * @param {number} chrono - chronotype in [-1 owl .. +1 lark]
 * @returns {number} acrophase minute-of-day
 */
export function acrophaseFor(chrono) {
  const c = Math.max(-1, Math.min(1, Number(chrono) || 0));
  return ACROPHASE - c * CHRONO_SHIFT;
}

/**
 * Process C: circadian alertness ∈ [0,1] at minute-of-day.
 * Cosine peaked at acrophase.
 */
export function processC(minuteOfDay, chrono = 0) {
  const phase = acrophaseFor(chrono);
  const t = ((minuteOfDay % DAY) + DAY) % DAY;
  // alertness high near phase, low 12h later
  const angle = (2 * Math.PI * (t - phase)) / DAY;
  return 0.5 + 0.5 * Math.cos(angle);
}

/**
 * Process S step. Pure ODE.
 * @param {number} S - current pressure [0,1]
 * @param {boolean} asleep
 * @param {number} dtMinutes
 */
export function stepS(S, asleep, dtMinutes = 1) {
  const s0 = Math.max(0, Math.min(1, S));
  const dt = Math.max(0, dtMinutes);
  if (asleep) {
    // discharge toward 0
    const k = Math.exp(-dt / TAU_SLEEP);
    return s0 * k;
  }
  // climb toward 1
  const k = Math.exp(-dt / TAU_WAKE);
  return 1 - (1 - s0) * k;
}

/**
 * Should the body want to sleep? High S + low C.
 */
export function sleepDrive(S, C) {
  return Math.max(0, Math.min(1, S * (1 - C)));
}

/**
 * Wake threshold: when C rises above remaining S debt shaped by chronotype.
 */
export function shouldWake(S, C, minuteOfDay, chrono = 0) {
  const t = ((minuteOfDay % DAY) + DAY) % DAY;
  if (t < WAKE_EARLIEST) return false;
  if (t > WAKE_LATEST) return true;
  // wake when circadian alertness overtakes residual pressure
  return C > S * 0.85 + 0.1 * (1 - (chrono + 1) / 2);
}

/**
 * Full sleep state for a person Design.
 * design: { chronotype?, gate?, line?, ... } — chronotype can be derived from Design later.
 */
export function createSleepState(design = {}) {
  const chrono = design.chronotype != null ? design.chronotype : 0;
  return {
    S: DEFAULT_S,
    asleep: false,
    chrono,
    minuteOfDay: 8 * 60,
    designKey: design.addressKey || null,
  };
}

export function tickSleep(state, dtMinutes = 1) {
  const C = processC(state.minuteOfDay, state.chrono);
  let { S, asleep, minuteOfDay, chrono } = state;
  S = stepS(S, asleep, dtMinutes);
  minuteOfDay = (minuteOfDay + dtMinutes) % DAY;

  if (asleep) {
    if (shouldWake(S, processC(minuteOfDay, chrono), minuteOfDay, chrono)) {
      asleep = false;
    }
  } else {
    if (sleepDrive(S, C) > 0.72 && (minuteOfDay > 21 * 60 || minuteOfDay < 5 * 60)) {
      asleep = true;
    }
  }

  return {
    ...state,
    S,
    C,
    asleep,
    minuteOfDay,
    drive: sleepDrive(S, C),
    grogginess: asleep ? 0 : Math.max(0, S - 0.25),
  };
}
