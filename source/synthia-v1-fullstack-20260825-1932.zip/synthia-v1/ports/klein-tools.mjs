/**
 * Modernized Klein semantic tools surface (beyond ATO).
 * Each tool is a semantic triple-capable operator: (subject, relation, object/tool).
 * Pure JS, deterministic, address/Design conditioned.
 *
 * Target direction: public ~16 → expanded set that ToolFactory can embody.
 * These are real operators, not placeholders.
 */

import { completeAnalogy, toBitString, normalizeVector } from '../boolean-ato.mjs';

/** Semantic triple: [subject, relation, object] where object may itself be a tool id. */
export function triple(subject, relation, object) {
  return Object.freeze({ subject, relation, object, kind: 'semantic-triple' });
}

/** 1. Analogy completion (Klein Boolean ATO) */
export function toolAnalogy(A, B, C, mode = 'equivalence') {
  const r = completeAnalogy(A, B, C, mode);
  return {
    id: 'klein:analogy',
    triple: triple(A, `${mode}:${toBitString(r.relation)}`, r.result),
    relation: r.relation,
    result: r.result,
    bits: toBitString(r.result),
  };
}

/** 2. Disseminate / transitive reachability over a link list (Warshall-style). */
export function toolDisseminate(nodes, links) {
  const n = nodes.length;
  const idx = new Map(nodes.map((id, i) => [id, i]));
  const reach = Array.from({ length: n }, () => Array(n).fill(false));
  for (let i = 0; i < n; i++) reach[i][i] = true;
  for (const [a, b] of links) {
    const i = idx.get(a);
    const j = idx.get(b);
    if (i != null && j != null) reach[i][j] = true;
  }
  for (let k = 0; k < n; k++) {
    for (let i = 0; i < n; i++) {
      if (!reach[i][k]) continue;
      for (let j = 0; j < n; j++) {
        if (reach[k][j]) reach[i][j] = true;
      }
    }
  }
  const edges = [];
  for (let i = 0; i < n; i++) {
    for (let j = 0; j < n; j++) {
      if (i !== j && reach[i][j]) edges.push([nodes[i], nodes[j]]);
    }
  }
  return {
    id: 'klein:disseminate',
    triple: triple(nodes, 'reaches', edges),
    edges,
    matrix: reach,
  };
}

/** 3. Paraphrase / morph surface: rewrite tokens via relation map. */
export function toolParaphrase(tokens, relationMap = {}) {
  const out = tokens.map((t) => relationMap[t] ?? t);
  return {
    id: 'klein:paraphrase',
    triple: triple(tokens, 'paraphrase', out),
    output: out,
    text: out.join(' '),
  };
}

/** 4. Narrative phase step (AutoNovel-compatible). */
export function toolNarrativePhase(phase = 0, events = {}) {
  const phases = ['Exposition', 'Complication', 'Climax', 'Resolution'];
  const i = Math.max(0, Math.min(3, Math.floor(phase * 4)));
  const name = phases[i];
  const beat = {
    phase: name,
    index: i,
    intensity: events.intensity ?? (i + 1) / 4,
    focus: events.focus || null,
  };
  return {
    id: 'klein:narrative-phase',
    triple: triple(phase, 'phase', beat),
    beat,
  };
}

/** 5. Feature space nearest (Klein FeatureSpace style). */
export function toolNearest(query, items, toVec) {
  const q = normalizeVector(toVec(query));
  let best = null;
  let bestScore = -Infinity;
  for (const item of items) {
    const v = normalizeVector(toVec(item));
    let dot = 0;
    const n = Math.min(q.length, v.length);
    for (let i = 0; i < n; i++) dot += q[i] * v[i];
    if (dot > bestScore) {
      bestScore = dot;
      best = item;
    }
  }
  return {
    id: 'klein:nearest',
    triple: triple(query, 'nearest', best),
    best,
    score: bestScore,
  };
}

/** 6. Retarget plan: map plan steps through an analogy relation. */
export function toolRetarget(planSteps, relationBits) {
  const rel = normalizeVector(relationBits);
  const out = planSteps.map((step, i) => {
    const seed = normalizeVector(
      String(step)
        .split('')
        .map((c) => c.charCodeAt(0) % 2)
    );
    const mapped = seed.map((b, j) => (b ^ (rel[j % rel.length] || 0)) & 1);
    return { step, mapped: toBitString(mapped), index: i };
  });
  return {
    id: 'klein:retarget',
    triple: triple(planSteps, toBitString(rel), out),
    steps: out,
  };
}

/** Registry of available Klein tools for ToolFactory / organism routing. */
export const KLEIN_TOOL_REGISTRY = Object.freeze([
  { id: 'klein:analogy', fn: toolAnalogy, level: 'semantic' },
  { id: 'klein:disseminate', fn: toolDisseminate, level: 'semantic' },
  { id: 'klein:paraphrase', fn: toolParaphrase, level: 'surface' },
  { id: 'klein:narrative-phase', fn: toolNarrativePhase, level: 'narrative' },
  { id: 'klein:nearest', fn: toolNearest, level: 'semantic' },
  { id: 'klein:retarget', fn: toolRetarget, level: 'plan' },
]);

export function listKleinTools() {
  return KLEIN_TOOL_REGISTRY.map(({ id, level }) => ({ id, level }));
}

export function runKleinTool(id, ...args) {
  const entry = KLEIN_TOOL_REGISTRY.find((t) => t.id === id);
  if (!entry) return { error: `unknown tool ${id}` };
  return entry.fn(...args);
}
