/**
 * Full stack exercise: Design load → mesh → Klein tools → video ingest
 * → ToolFactory person tools → Adaya mount → AutoNova video → autonomy/bootstrap
 */

import { sampleChart, loadDesignFromChart } from './ports/design-loader.mjs';
import {
  makeDesign,
  createPersonSlice,
  personIngest,
  tickEmbodied,
  meshIdentity,
} from './synthia-integrated.mjs';
import { createMesh, registerOnMesh, contact, pull, tryPrivateShare, meshSnapshot } from './ports/mesh.mjs';
import { listKleinTools, runKleinTool, toolAnalogy, toolDisseminate, toolNarrativePhase } from './ports/klein-tools.mjs';
import { prepareVideoIngest } from './ports/video-ingest.mjs';
import { writePPMSequence } from './organs/video-frames.mjs';
import { mountOnHost, createMinimalHost } from './organs/adaya-mount.mjs';
import {
  createAutonomyState,
  autonomousCycle,
  installManifest,
  serviceWorkerSource,
  autonomyReport,
} from './organs/autonomous-bootstrap.mjs';
import { writeFileSync, mkdirSync, readdirSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';

const root = dirname(fileURLToPath(import.meta.url));

console.log('=== Synthia full stack ===\n');

// 1) Real Design input
const chartA = sampleChart({ name: 'Person A', gate: 20, line: 3, dimension: 'Design' });
const chartB = sampleChart({ name: 'Person B', gate: 20, line: 5, dimension: 'Design' }); // same gate, different line
const chartC = sampleChart({ name: 'Person C', gate: 61, line: 1, dimension: 'Movement' });

console.log('1. DESIGN');
console.log('  A:', chartA.addressKey);
console.log('  B:', chartB.addressKey, '(same gate as A)');
console.log('  C:', chartC.addressKey);

// 2) Mesh
const mesh = createMesh();
registerOnMesh(mesh, chartA);
registerOnMesh(mesh, chartB);
registerOnMesh(mesh, chartC);
console.log('\n2. MESH (latent)');
console.log('  snapshot:', JSON.stringify(meshSnapshot(mesh), null, 2).split('\n').slice(0, 12).join('\n'));
let c = contact(mesh, chartA.addressKey, chartB.addressKey);
console.log('  contact A↔B:', c);
c = pull(mesh, chartA.addressKey, chartB.addressKey);
console.log('  pull A↔B:', c);
console.log('  private share A↔B:', tryPrivateShare(mesh, chartA.addressKey, chartB.addressKey));

// 3) Klein tools
console.log('\n3. KLEIN TOOLS');
console.log('  registry:', listKleinTools());
const bit = (s) => s.split('').map(Number);
const ana = toolAnalogy(bit('101010'), bit('110011'), bit('101010'));
console.log('  analogy result bits:', ana.bits);
console.log('  disseminate:', toolDisseminate(['a', 'b', 'c'], [['a', 'b'], ['b', 'c']]).edges);
console.log('  narrative:', toolNarrativePhase(0.6).beat);

// 4) Person slices + ToolFactory + video ingest
const personA = createPersonSlice(chartA);
const personC = createPersonSlice(chartC);

const textContent = 'The environment holds energy near creation and seeing.';
const tA = personIngest(personA, textContent, { name: 'field' });
const tA2 = personIngest(personA, textContent, { name: 'field' });
const tC = personIngest(personC, textContent, { name: 'field' });
console.log('\n4. PERSON + TOOLFACTORY');
console.log('  same Design+content reused?', tA.toolId === tA2.toolId, tA2.reused);
console.log('  A vs C different?', tA.toolId !== tC.toolId);
console.log('  factory A:', tA.tool.factory?.generated?.name, tA.tool.factory?.generated?.levelName);

// Video from existing PPM if present, else from AutoNova frames
const videoDir = join(root, 'artifacts-video');
let videoPaths = [];
try {
  videoPaths = readdirSync(videoDir)
    .filter((f) => f.endsWith('.ppm'))
    .map((f) => join(videoDir, f));
} catch {}
if (videoPaths.length) {
  const prepared = prepareVideoIngest(videoPaths, { name: 'nova-sequence', description: 'AutoNova PPM sequence' });
  const vIn = personIngest(personA, prepared.text, { name: prepared.summary.name, kindHint: 'video' });
  console.log('  video ingest tool:', vIn.toolId.slice(0, 48) + '...', 'reused?', vIn.reused);
  console.log('  video address gate:', vIn.tool.address.gate);
} else {
  console.log('  (no PPM yet — will write from AutoNova)');
}

// 5) Adaya mount
const host = createMinimalHost();
const { pack } = mountOnHost(host, chartA, 'synthiaV1');
console.log('\n5. ADAYA MOUNT');
console.log('  organs:', Object.keys(host.organs));
console.log('  fabric:', host.processFabric);

// 6) Video frames out
const frames = tA.tool.videoFrames(6, 64, 36);
const outDir = join(root, 'artifacts-video');
mkdirSync(outDir, { recursive: true });
const paths = await writePPMSequence(frames, outDir, 'stack');
console.log('\n6. VIDEO OUT');
console.log('  wrote', paths.length, 'frames');

// Autonomy / self-install surface
const auto = createAutonomyState(chartA);
autonomousCycle(auto, { openNeed: { kind: 'residence', subject: 'phone' } });
autonomousCycle(auto, { lastResult: { ok: true } });
const manifest = installManifest({ startUrl: './phone-shell.html' });
writeFileSync(join(root, 'manifest.webmanifest'), JSON.stringify(manifest, null, 2));
writeFileSync(join(root, 'synthia-sw.js'), serviceWorkerSource());
console.log('\n7. AUTONOMY / SELF-INSTALL SURFACE');
console.log(JSON.stringify(autonomyReport(auto), null, 2));
console.log('  wrote manifest.webmanifest + synthia-sw.js');
console.log('  phone shell: phone-shell.html');

console.log('\n=== full stack complete ===');
