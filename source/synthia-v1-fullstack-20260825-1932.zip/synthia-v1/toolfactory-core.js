const REAL_TRIGRAMS = {
  Qian: { name: 'Qian', symbol: '☰', meaning: 'Heaven', lines: [1,1,1], binary: 7 },
  Kun:  { name: 'Kun',  symbol: '☷', meaning: 'Earth',   lines: [0,0,0], binary: 0 },
  Zhen: { name: 'Zhen', symbol: '☳', meaning: 'Thunder', lines: [1,0,0], binary: 1 },
  Xun:  { name: 'Xun',  symbol: '☴', meaning: 'Wind',    lines: [0,1,1], binary: 6 },
  Kan:  { name: 'Kan',  symbol: '☵', meaning: 'Water',   lines: [0,1,0], binary: 2 },
  Li:   { name: 'Li',   symbol: '☲', meaning: 'Fire',    lines: [1,0,1], binary: 5 },
  Gen:  { name: 'Gen',  symbol: '☶', meaning: 'Mountain',lines: [0,0,1], binary: 4 },
  Dui:  { name: 'Dui',  symbol: '☱', meaning: 'Lake',    lines: [1,1,0], binary: 3 },
};
const REAL_KW_DATA = [
  [1,'Qian','Qian','Qian','乾','The Creative'],[2,'Kun','Kun','Kun','坤','The Receptive'],
  [3,'Zhen','Kan','Zhun','屯','Difficulty at the Beginning'],[4,'Kan','Gen','Meng','蒙','Youthful Folly'],
  [5,'Qian','Kan','Xu','需','Waiting'],[6,'Kan','Qian','Song','訟','Conflict'],
  [7,'Kun','Kan','Shi','師','The Army'],[8,'Kan','Kun','Bi','比','Holding Together'],
  [9,'Qian','Xun','Xiao Xu','小畜','Small Taming'],[10,'Dui','Qian','Lu','履','Treading'],
  [11,'Qian','Kun','Tai','泰','Peace'],[12,'Kun','Qian','Pi','否','Standstill'],
  [13,'Li','Qian','Tong Ren','同人','Fellowship'],[14,'Qian','Li','Da You','大有','Great Possession'],
  [15,'Gen','Kun','Qian','謙','Modesty'],[16,'Kun','Zhen','Yu','豫','Enthusiasm'],
  [17,'Zhen','Dui','Sui','隨','Following'],[18,'Xun','Gen','Gu','蠱','Work on the Decayed'],
  [19,'Dui','Kun','Lin','臨','Approach'],[20,'Kun','Xun','Guan','觀','Contemplation'],
  [21,'Zhen','Li','Shi He','噬嗑','Biting Through'],[22,'Li','Gen','Bi','賁','Grace'],
  [23,'Kun','Gen','Bo','剝','Splitting Apart'],[24,'Zhen','Kun','Fu','復','Return'],
  [25,'Zhen','Qian','Wu Wang','無妄','Innocence'],[26,'Qian','Gen','Da Xu','大畜','Great Taming'],
  [27,'Zhen','Gen','Yi','頤','Nourishment'],[28,'Xun','Dui','Da Guo','大過','Great Exceeding'],
  [29,'Kan','Kan','Kan','坎','The Abysmal'],[30,'Li','Li','Li','離','The Clinging'],
  [31,'Gen','Dui','Xian','咸','Influence'],[32,'Xun','Zhen','Heng','恆','Duration'],
  [33,'Gen','Qian','Dun','遯','Retreat'],[34,'Qian','Zhen','Da Zhuang','大壯','Great Power'],
  [35,'Kun','Li','Jin','晉','Progress'],[36,'Li','Kun','Ming Yi','明夷','Darkening of the Light'],
  [37,'Li','Xun','Jia Ren','家人','The Family'],[38,'Dui','Li','Kui','睽','Opposition'],
  [39,'Gen','Kan','Jian','蹇','Obstruction'],[40,'Kan','Zhen','Jie','解','Deliverance'],
  [41,'Dui','Gen','Sun','損','Decrease'],[42,'Zhen','Xun','Yi','益','Increase'],
  [43,'Qian','Dui','Guai','夬','Breakthrough'],[44,'Xun','Qian','Gou','姤','Coming to Meet'],
  [45,'Kun','Dui','Cui','萃','Gathering'],[46,'Xun','Kun','Sheng','升','Pushing Upward'],
  [47,'Kan','Dui','Kun','困','Oppression'],[48,'Xun','Kan','Jing','井','The Well'],
  [49,'Li','Dui','Ge','革','Revolution'],[50,'Xun','Li','Ding','鼎','The Cauldron'],
  [51,'Zhen','Zhen','Zhen','震','The Arousing'],[52,'Gen','Gen','Gen','艮','Keeping Still'],
  [53,'Gen','Xun','Jian','漸','Gradual Progress'],[54,'Dui','Zhen','Gui Mei','歸妹','The Marrying Maiden'],
  [55,'Li','Zhen','Feng','豐','Abundance'],[56,'Gen','Li','Lu','旅','The Wanderer'],
  [57,'Xun','Xun','Xun','巽','The Gentle'],[58,'Dui','Dui','Dui','兌','The Joyous'],
  [59,'Kan','Xun','Huan','渙','Dispersion'],[60,'Dui','Kan','Jie','節','Limitation'],
  [61,'Dui','Xun','Zhong Fu','中孚','Inner Truth'],[62,'Gen','Zhen','Xiao Guo','小過','Small Exceeding'],
  [63,'Li','Kan','Ji Ji','既濟','After Completion'],[64,'Kan','Li','Wei Ji','未濟','Before Completion'],
];
function buildRealHexagrams() {
  return REAL_KW_DATA.map(([kw, lowerName, upperName, name, char, keyword]) => {
    const lower = REAL_TRIGRAMS[lowerName], upper = REAL_TRIGRAMS[upperName];
    const lines = [...lower.lines, ...upper.lines];
    const fuxi = lines.reduce((acc, l, i) => acc + l * (1 << i), 0);
    const complement = fuxi ^ 63;
    const reverseFuxi = 63 - fuxi;
    const nuclearLower = [lines[1], lines[2], lines[3]];
    const nuclearUpper = [lines[2], lines[3], lines[4]];
    const nuclearFuxi = nuclearLower.reduce((a, l, i) => a + l * (1 << i), 0)
      + (nuclearUpper.reduce((a, l, i) => a + l * (1 << i), 0) << 3);
    return { kw, name, char, keyword, lower: lowerName, upper: upperName, lines,
      fuxi, complement, reverseFuxi, nuclearFuxi,
      phaseState: lines.map(l => ({ value: l, velocity: 0, tension: 0 })) };
  });
}
const HEXAGRAMS = buildRealHexagrams();
const BY_FUXI = new Array(64);
HEXAGRAMS.forEach(h => { BY_FUXI[h.fuxi] = h; });
const BY_KW_NUM = new Array(65);
HEXAGRAMS.forEach(h => { BY_KW_NUM[h.kw] = h; });
const BY_KW = BY_FUXI; // alias -- old ToolFactory code indexes this by fuxi, see note above

// The 5 orderings -> the 5 State Space layers (ported from sequences.js)
const MAWANGDUI_TRIGRAM_ORDER = [7, 0, 1, 4, 2, 5, 3, 6];
function mawangduiRank(fuxi) {
  const upperRank = MAWANGDUI_TRIGRAM_ORDER.indexOf((fuxi >> 3) & 0b111);
  const lowerRank = MAWANGDUI_TRIGRAM_ORDER.indexOf(fuxi & 0b111);
  return upperRank * 8 + lowerRank;
}
function buildRealSequences() {
  const fuxiSeq = [...Array(64).keys()];
  const mawangduiSeq = [...Array(64).keys()].sort((a, b) => mawangduiRank(a) - mawangduiRank(b));
  const kingWenSeq = HEXAGRAMS.slice().sort((a, b) => a.kw - b.kw).map(h => h.fuxi);
  const reverseFuxiSeq = [...fuxiSeq].reverse();
  const complementSeq = fuxiSeq.map(f => f ^ 63);
  return {
    fuxi: { id: 'fuxi', name: 'Fu Xi', description: 'Binary natural sequence.', sequence: fuxiSeq },
    mawangdui: { id: 'mawangdui', name: 'Mawangdui', description: 'Silk-manuscript sequence, grouped by upper trigram.', sequence: mawangduiSeq },
    kingwen: { id: 'kingwen', name: 'King Wen', description: 'Traditional received sequence -- the live reading layer.', sequence: kingWenSeq },
    reverse: { id: 'reverse', name: 'Reverse Fu Xi', description: 'Descending binary -- retrospective/temporal layer.', sequence: reverseFuxiSeq },
    complement: { id: 'complement', name: 'Complement Fu Xi', description: 'Bitwise NOT of Fu Xi -- the shadow sequence.', sequence: complementSeq },
  };
}
const SEQUENCES = buildRealSequences();

class ResonanceNode {
  constructor(gateId, gridPos) {
    this.id = gateId;
    this.gridPos = gridPos;
    const realHits = (window.REAL_CHART_SEED || []).filter(n => n.gate === gateId);
    this.chartBody = realHits.length ? realHits.map(h => h.body).join('+') : null;
    this.chartLine = realHits.length ? realHits[0].line : null; // real per-instance line, if a body sits here
    this.being    = realHits.length ? realHits.reduce((s,h)=>s+h.line,0) / realHits.length / 6 : Math.random();
    this.design   = realHits.length ? realHits.reduce((s,h)=>s+h.color,0) / realHits.length / 6 : Math.random();
    this.movement = realHits.length ? realHits.reduce((s,h)=>s+h.tone,0) / realHits.length / 6 : Math.random();
    this.evolution= Math.random();
    this.space    = Math.random();
    this.binaryState  = Math.random() > 0.75 ? 1 : 0;
    this.trinaryState = 0;
    this.hexState     = 0;
    this.level        = 0;
    this.tension      = 0;
    this.activationHistory = new Float32Array(34);
    this.historyPtr = 0;
  }
  recordActivation(t) {
    this.activationHistory[this.historyPtr % 34] = t;
    this.historyPtr++;
  }
  activeState() { return this.binaryState === 1; }
}

class MonopoleRouter {
  constructor(nodes) {
    this.nodes = nodes;
    this.attractor = null;
    this.coherence = 0;
  }
  route() {
    let maxScore = -1;
    for (const node of this.nodes) {
      const score = node.movement * 0.3 + node.being * 0.3 + node.space * 0.4;
      if (score > maxScore) { maxScore = score; this.attractor = node; }
    }
    this.coherence = Math.min(1.0, maxScore * 0.85);
  }
}

class FieldEngine {
  constructor() {
    this.nodes = [];
    this.nodeMap = {};
    for (let i = 0; i < 64; i++) {
      const gateId = GATE_GRID_ORDER[i];
      const node = new ResonanceNode(gateId, GATE_GRID_POS[gateId]);
      this.nodes.push(node);
      this.nodeMap[gateId] = node;
    }
    this.monopole = new MonopoleRouter(this.nodes);
    this.generation = 0;
  }
  // Was: random coin-flip per node (Math.random() < 0.05). Now mirrors the
  // real 'kingwen' layer of stateSpace (defined further down) -- each
  // ResonanceNode's binaryState/tension reflects genuine attractor-based
  // phase dynamics (a HexagramNode's line values relaxing toward/crossing
  // their classical yin/yang attractor) rather than chance. stateSpace
  // ticks on its own independent timer; this just reads its current state.
  step() {
    this.generation++;
    this.monopole.route();
    if (typeof stateSpace === 'undefined') return; // defined after this class; guarded for load order
    const liveLayer = stateSpace.getLayer('kingwen');
    if (!liveLayer) return;
    for (const node of this.nodes) {
      const hexNode = liveLayer.getNode(BY_KW_NUM[node.id]?.fuxi);
      if (!hexNode) continue;
      const wasBinary = node.binaryState;
      node.binaryState = hexNode.phase.some(p => p.changing) ? 1 : 0;
      node.tension = Math.min(1, hexNode.energy * 4);
      node.being = hexNode.phase.reduce((s, p) => s + p.value, 0) / 6;
      if (node.binaryState === 1 && wasBinary !== 1) node.recordActivation(Date.now());
    }
  }
}

class MorphLoop {
  constructor(fieldEngine) {
    this.field = fieldEngine;
    this.queue = [];
  }
  enqueue(transform) { this.queue.push(transform); }
  processNext() {
    if (this.queue.length === 0) return null;
    const task = this.queue.shift();
    const node = this.field.nodeMap[task.targetGate];
    if (node) {
      node.being = Math.min(1.0, Math.max(0.0, node.being + (task.value || 0.1)));
      node.movement = Math.abs(Math.sin(node.being * Math.PI));
      if (task.state !== undefined) node.binaryState = task.state;
      node.tension = Math.random();
      node.recordActivation(Date.now());
    }
    return { task, node };
  }
}

// ══════════════════════════════════════════════════════════════════════
// REAL DISEMINER: dependency network + Warshall's-algorithm transitive
// closure (Klein, Lieman & Lindstrom, 1968). Every gate-to-gate morph
// event the engine actually processes becomes a real dependency link;
// "plausible(a,b)" and "reachableFrom(a)" answer from the ACTUAL recorded
// history via true transitive closure -- not a random template.
// Self-test below reproduces the paper's own worked example.
// ══════════════════════════════════════════════════════════════════════
class DependencyNetwork {
  constructor() {
    this.transitive = new Map();
    this.intransitive = new Map();
    this.nodes = new Set();
    this.M = null;
  }
  addLink(a, b, transitive = true) {
    this.nodes.add(a); this.nodes.add(b);
    const store = transitive ? this.transitive : this.intransitive;
    if (!store.has(a)) store.set(a, new Set());
    store.get(a).add(b);
    this.M = null; // invalidate cached closure
  }
  closure() {
    const nodes = [...this.nodes];
    const T = new Map(nodes.map(n => [n, new Set(this.transitive.get(n) || [])]));
    for (const k of nodes) {
      for (const i of nodes) {
        if (!T.get(i).has(k)) continue;
        for (const j of nodes) {
          if (T.get(k).has(j)) T.get(i).add(j);
        }
      }
    }
    const M = new Map(nodes.map(n => [n, new Set(T.get(n))]));
    for (const [a, set] of this.intransitive) {
      for (const b of set) {
        if (!M.has(a)) M.set(a, new Set());
        M.get(a).add(b);
        for (const n of nodes) {
          if (T.get(n) && T.get(n).has(a)) M.get(n).add(b);
        }
      }
    }
    this.M = M;
    return M;
  }
  plausible(a, b) { if (!this.M) this.closure(); return !!(this.M.get(a) && this.M.get(a).has(b)); }
  reachableFrom(a) { if (!this.M) this.closure(); return this.M.get(a) ? [...this.M.get(a)] : []; }
  linkCount() { let n = 0; for (const s of this.transitive.values()) n += s.size; for (const s of this.intransitive.values()) n += s.size; return n; }
}

// The OS-container-facing wrapper: turns real morph events into real
// dependency links, and turns real closure queries into grounded English
// using the real GATE_DATA names -- this replaces the old 3-template filler.
class Disseminer {
  constructor() { this.net = new DependencyNetwork(); }
  recordMorph(fromGate, toGate) { this.net.addLink(fromGate, toGate, true); }
  express(gateA, gateB, gateC, tension) {
    const nameOf = g => `Gate ${g} (${GATE_DATA[g]?.name || '?'})`;
    const direct = this.net.transitive.get(gateA)?.has(gateB);
    const path = this.net.plausible(gateA, gateB);
    if (this.net.linkCount() === 0) {
      return `No morph history recorded yet -- ${nameOf(gateA)} has no real dependency links to report on. (Trigger some morphs first via AutoNovel or code ingestion.)`;
    }
    if (direct) return `${nameOf(gateA)} has a directly recorded transition to ${nameOf(gateB)} (tension ${(tension||0).toFixed(2)}).`;
    if (path) return `${nameOf(gateA)} transitively reaches ${nameOf(gateB)} through the recorded morph history (not a direct link, but a real chain of them).`;
    return `${nameOf(gateA)} has no recorded path to ${nameOf(gateB)} yet -- these two gates haven't been connected by any morph this session.`;
  }
}

// AutoNovel keeps its real phase state machine; its "prose" now comes from
// the real Disseminer above (grounded in actual recorded morphs) instead of
// a fixed 4-label cycle with fake filler text.
class AutoNovel {
  constructor(morphLoop, disseminer) {
    this.morphLoop = morphLoop;
    this.disseminer = disseminer;
    this.plotPhaseIdx = 0;
    this.phases = ['Exposition', 'Complication', 'Climax', 'Resolution'];
  }
  get currentPhase() { return this.phases[this.plotPhaseIdx]; }
  advancePlot(activeGate, analogueGate) {
    this.plotPhaseIdx = (this.plotPhaseIdx + 1) % 4;
    const phaseName = this.currentPhase;
    this.morphLoop.enqueue({
      targetGate: activeGate,
      value: (this.plotPhaseIdx + 1) * 0.2,
      state: this.plotPhaseIdx >= 2 ? 1 : 0,
      layer: phaseName
    });
    const cGate = solveAnalogy(activeGate, analogueGate, activeGate, 6);
    this.disseminer.recordMorph(activeGate, cGate); // this IS the real dependency data DISEMINER reasons over
    const prose = this.disseminer.express(activeGate, analogueGate, cGate, (this.plotPhaseIdx + 1) / 4);
    return { phase: phaseName, prose, activeGate, cGate };
  }
}

class OSCodeContainer {
  constructor(fieldEngine, morphLoop, disseminer) {
    this.field = fieldEngine;
    this.morphLoop = morphLoop;
    this.disseminer = disseminer;
    this.registry = new Map();
    this.lastGate = null;
  }
  ingest(moduleName, codeString) {
    let hash = 0;
    for (let i = 0; i < codeString.length; i++) hash = (hash * 31 + codeString.charCodeAt(i)) >>> 0;
    const gateId = (hash % 64) + 1;
    const record = { name: moduleName, originalCode: codeString, gateId: gateId, ingestedAt: Date.now() };
    this.registry.set(moduleName, record);
    this.morphLoop.enqueue({ targetGate: gateId, value: 0.5, state: 1, layer: 'code_ingestion' });
    if (this.lastGate !== null && this.lastGate !== gateId) this.disseminer.recordMorph(this.lastGate, gateId);
    this.lastGate = gateId;
    return { moduleName, gateId, hash };
  }
  project(moduleName) {
    const record = this.registry.get(moduleName);
    if (!record) return null;
    const node = this.field.nodeMap[record.gateId];
    const tension = node ? node.tension : 0.5;
    const being = node ? node.being : 0.5;
    const projectedCode = `// Projected Code Module: ${record.name}
// State Anchor: Gate ${record.gateId} | Field Being: ${being.toFixed(3)} | Tension: ${tension.toFixed(3)}

export function ${record.name}_runtime(input) {
  const stateVector = { being: ${being.toFixed(3)}, tension: ${tension.toFixed(3)} };
  console.log("[OS Container] Executing projected code:", stateVector);
  if (${being} > 0.4) {
    return { status: "ACTIVE_PROJECTED", input, result: (${record.originalCode})(input) };
  } else {
    return { status: "MUTATED_DORMANT", input, stateVector };
  }
}`;
    return projectedCode;
  }
}

class HippocampalBuffer {
  constructor() { this.traces = []; }
  encodeEpisode(node, timestamp) {
    const trace = {
      ts: timestamp, gate: node.id,
      bitState: (node.binaryState << 1) | (node.trinaryState > 0 ? 1 : 0),
      tension: Math.round(node.tension * 100) / 100,
    };
    this.traces.push(trace);
    if (this.traces.length > 89) this.traces.shift();
    return trace;
  }
}

// ══════════════════════════════════════════════════════════════════════
// BROWSER-SAFE EVENT EMITTER
// Replaces Node's built-in `events` module, which the real ToolFactory's
// Level-6 (Channel) template originally imported. There is no server here
// by design, so this is a minimal same-behavior stand-in that runs in any
// browser tab with zero dependencies.
// ══════════════════════════════════════════════════════════════════════
class BrowserEventEmitter {
  constructor() { this._listeners = {}; }
  on(event, fn) { (this._listeners[event] ||= []).push(fn); return this; }
  emit(event, ...args) { (this._listeners[event] || []).forEach(fn => fn(...args)); return true; }
}

// ══════════════════════════════════════════════════════════════════════
// REAL 8-LEVEL TOOL FACTORY
// Ported from GNN-Compute-HTML/src/generators/ToolFactory.js, verified
// independently in a standalone Node test before being placed here (all
// 8 levels execute without error; Level 4 genuinely learns/analyzes;
// Level 7 produces genuinely different output across repeated calls on
// the same learned text -- confirmed, not assumed).
//
// Changes made to port it into this single-file, server-free page:
//   - `import`/`export` (ES module syntax) stripped from every template,
//     since there's no bundler here -- code is executed directly via
//     `new Function(...)`.
//   - Level 6's `import { EventEmitter } from 'events'` (a Node built-in,
//     unavailable in a browser) replaced with BrowserEventEmitter above.
//   - `uuidv4` (an npm package) replaced with the browser-native
//     `crypto.randomUUID()`.
//   - BY_FUXI (from the original project's hexagram data file) replaced
//     with BY_KW, built from this file's own GATE_DATA + the Fu-Xi/King-
//     Wen table (see the unverified-data note at the top of the page).
//   - Levels 0 and 5 declare their value under a prefixed name
//     (BASE_X / RULE_X) rather than the tool's own `name` -- this was a
//     real bug caught during verification; `retrievalName()` below
//     accounts for it explicitly rather than silently failing.
// ══════════════════════════════════════════════════════════════════════
const TF_LEVELS = [
  { n: 0, name: 'Base',     description: 'Quantum fragment — 5-state seed value' },
  { n: 1, name: 'Tone',     description: 'Yin/yang classifier — 1-line tool' },
  { n: 2, name: 'Color',    description: 'I Ching line — filter / predicate' },
  { n: 3, name: 'Bigram',   description: 'ARC×ZOD pattern — 2-line matcher' },
  { n: 4, name: 'Trigram',  description: 'C+T+B analyzer — 3-line structural tool' },
  { n: 5, name: 'Hexagram', description: 'Gate — two trigrams, grammar rule' },
  { n: 6, name: 'Channel',  description: 'Two gates via changing line — connector' },
  { n: 7, name: 'Circuit',  description: 'Three channels — AutoLing-scale system' },
];

const TF_TEMPLATES = {
  0: (ctx) => `const BASE_${ctx.toolName.toUpperCase()} = Object.freeze({
  address: '${ctx.address}', value: ${ctx.base}, tone: ${ctx.tone}, color: ${ctx.color},
  yang: ${ctx.classical === 1}, seed: ${ctx.fuxi ?? 0},
});`,

  1: (ctx) => `function ${ctx.toolName}(value) {
  const attractor = ${ctx.classical === 1 ? 0.75 : 0.25};
  const isYang = value > 0.5;
  const tension = Math.abs(value - attractor);
  return { isYang, isYin: !isYang, value, tension, changing: tension > 0.35 };
}`,

  2: (ctx) => `function ${ctx.toolName}(items, featureKey = null) {
  const FEATURE_WEIGHTS = { isYang: ${ctx.classical}, color: ${ctx.color}, tone: ${ctx.tone} };
  return items.filter(item => {
    if (featureKey) return Boolean(item[featureKey]);
    const score = Object.entries(FEATURE_WEIGHTS).reduce((s, [k, v]) =>
      s + (item[k] !== undefined ? Math.abs(item[k] - v) : 0), 0);
    return score < ${ctx.color};
  });
}`,

  3: (ctx) => `function ${ctx.toolName}(sequenceA, sequenceB) {
  const PATTERN = [${ctx.bigram1 ?? 0}, ${ctx.bigram2 ?? 0}];
  function encode(seq) { return seq.map(v => v > 0.5 ? 1 : 0); }
  const a = encode(Array.isArray(sequenceA) ? sequenceA : [sequenceA]);
  const b = encode(Array.isArray(sequenceB) ? sequenceB : [sequenceB]);
  const matchA = a.reduce((s, v) => s + (v === PATTERN[0] ? 1 : 0), 0) / a.length;
  const matchB = b.reduce((s, v) => s + (v === PATTERN[1] ? 1 : 0), 0) / b.length;
  return { match: (matchA + matchB) / 2, patternA: PATTERN[0], patternB: PATTERN[1], address: '${ctx.address}' };
}`,

  4: (ctx) => `class ${ctx.toolName} {
  constructor() {
    this.address = '${ctx.address}';
    this.features = { color: ${ctx.color}, tone: ${ctx.tone}, base: ${ctx.base} };
    this.table = new Map();
    this.learnCount = 0;
  }
  analyze(input) {
    const key = String(input).toLowerCase().slice(0, 32);
    if (this.table.has(key)) return this.table.get(key);
    const result = { input, features: this.features, pattern: [${ctx.bigram1 ?? 0}, ${ctx.bigram2 ?? 0}, ${ctx.base ?? 1}], address: this.address };
    this.table.set(key, result);
    return result;
  }
  learn(data) {
    this.learnCount++;
    (Array.isArray(data) ? data : [data]).forEach(item => this.analyze(item));
    return { learned: this.learnCount, tableSize: this.table.size };
  }
  generate(seed = null) {
    const entries = [...this.table.keys()];
    const base = seed || entries[Math.floor(Math.random() * entries.length)] || 'generate';
    return { generated: base + '_' + this.features.tone, address: this.address };
  }
}`,

  5: (ctx) => `const RULE_${ctx.toolName.toUpperCase()} = {
  id: '${ctx.toolName}', address: '${ctx.address}', gate: ${ctx.gate},
  lhs: '${ctx.lower || 'LOWER'}',
  rhs: ['${ctx.upper || 'UPPER'}', '${(ctx.name || 'RESULT').replace(/\s/g, '_')}'],
  features: { isFunction: ${ctx.classical ?? 0}, hasState: ${ctx.classical === 0 ? 1 : 0} },
  weight: 1,
  apply(context = {}) { this.weight += 0.01; return { rule: this.id, lhs: this.lhs, rhs: this.rhs, context, address: this.address }; },
  learn(example) { if (example?.lhs === this.lhs) this.weight += 0.1; return this; },
};`,

  6: (ctx) => `class ${ctx.toolName} extends __BrowserEventEmitter {
  constructor() {
    super();
    this.address = '${ctx.address}';
    this.from = { gate: ${ctx.fromFuxi ?? 0}, name: '${ctx.fromName || ''}' };
    this.to   = { gate: ${ctx.toFuxi ?? 0},   name: '${ctx.toName || ''}' };
    this.changingLines = ${JSON.stringify(ctx.changingLines || [])};
    this.history = [];
    this.grammar = { rules: [], lexicon: new Map() };
  }
  transmit(signal) {
    const packet = { signal, from: this.from, to: this.to, ts: Date.now(), address: this.address };
    this.history.push(packet);
    this.emit('signal', packet);
    return packet;
  }
  learn(text) {
    const tokens = text.toLowerCase().split(/\\s+/).filter(t => t.length > 1);
    tokens.forEach((tok, i) => {
      if (!this.grammar.lexicon.has(tok)) this.grammar.lexicon.set(tok, { weight: 1 });
      else this.grammar.lexicon.get(tok).weight += 0.05;
      if (i < tokens.length - 1) this.grammar.rules.push({ lhs: tok, rhs: tokens[i + 1], weight: 1 });
    });
    this.emit('learned', { tokens: tokens.length, address: this.address });
    return { tokens: tokens.length };
  }
}`,

  7: (ctx) => `class ${ctx.toolName} {
  constructor() {
    this.address = '${ctx.address}';
    this.signature = { from: ${ctx.fromFuxi ?? 0}, to: ${ctx.toFuxi ?? 0} };
    this.morpho = {
      table: new Map(),
      learn: (tokens) => tokens.forEach(t => this.morpho.table.set(t, (this.morpho.table.get(t) || 0) + 1)),
      analyze: (token) => ({ token, weight: this.morpho.table.get(token) || 0 }),
      generate: () => [...this.morpho.table.keys()][Math.floor(Math.random() * this.morpho.table.size)] || 'generate',
    };
    this.semnet = {
      nodes: new Map(), edges: [],
      addNode: (id, label) => this.semnet.nodes.set(id, { id, label, weight: 1 }),
      addEdge: (a, b, type) => this.semnet.edges.push({ a, b, type }),
      learn: (tokens) => tokens.forEach((t, i) => {
        if (!this.semnet.nodes.has(t)) this.semnet.addNode(t, t);
        if (i < tokens.length - 1) this.semnet.addEdge(t, tokens[i + 1], 'FOLLOWS');
      }),
    };
    this.generator = {
      rules: [],
      learn: (tokens) => tokens.forEach((t, i) => { if (i < tokens.length - 1) this.generator.rules.push({ lhs: t, rhs: tokens[i + 1], w: 1 }); }),
      generate: (seed) => {
        if (!this.generator.rules.length) return seed || '...';
        let cur = seed || this.generator.rules[0].lhs;
        const out = [cur];
        for (let i = 0; i < 15; i++) {
          const nexts = this.generator.rules.filter(r => r.lhs === cur);
          if (!nexts.length) break;
          cur = nexts[Math.floor(Math.random() * nexts.length)].rhs;
          out.push(cur);
        }
        return out.join(' ');
      },
    };
    this.learnCount = 0;
  }
  learn(text) {
    this.learnCount++;
    const tokens = text.toLowerCase().split(/\\s+/).filter(t => t.length > 1);
    this.morpho.learn(tokens); this.semnet.learn(tokens); this.generator.learn(tokens);
    return { learned: tokens.length, learnCount: this.learnCount };
  }
  generate(seed = null) {
    const word = this.morpho.generate();
    return this.generator.generate(seed || word);
  }
}`,
};

class ToolFactory {
  constructor() {
    this.generatedByLevel = new Array(8).fill(0);
  }

  detectLevel(event) {
    const { changingLines = [] } = event;
    if (!changingLines.length) return 5;
    const n = changingLines.length;
    if (n >= 3) return 6;
    if (n === 2) return 5;
    const line = changingLines[0];
    return (line.lineNumber - 1) % 3; // 0,1,2 -> Base/Tone/Color
  }

  // Levels 0 and 5 declare their value under a prefixed constant name,
  // not the tool's own `name` -- this accounts for that explicitly
  // instead of silently returning `undefined` for those two levels.
  retrievalName(name, level) {
    if (level === 0) return 'BASE_' + name.toUpperCase();
    if (level === 5) return 'RULE_' + name.toUpperCase();
    return name;
  }

  _makeName(event, level) {
    const fromHex = BY_KW[event.fromFuxi], toHex = BY_KW[event.toFuxi];
    const levelName = TF_LEVELS[level]?.name || 'Tool';
    const lines = (event.changingLines || []).map(l => l.lineNumber).join('');
    const from = (fromHex?.name || `H${event.fromFuxi}`).replace(/[^A-Za-z0-9]/g, '');
    const to = (toHex?.name || `H${event.toFuxi}`).replace(/[^A-Za-z0-9]/g, '');
    return `${levelName}${from}To${to}${lines ? `L${lines}` : ''}`;
  }

  generate(event) {
    const level = this.detectLevel(event);
    const template = TF_TEMPLATES[level] || TF_TEMPLATES[5];
    const fromHex = BY_KW[event.fromFuxi], toHex = BY_KW[event.toFuxi];
    const lineNum = event.changingLines?.[0]?.lineNumber || 1;

    const ctx = {
      ...event,
      toolName: this._makeName(event, level),
      address: `G${fromHex?.kw || 0}.L${lineNum}`,
      gate: fromHex?.kw, name: fromHex?.name, fuxi: fromHex?.fuxi,
      lower: fromHex?.lower, upper: fromHex?.upper,
      classical: fromHex?.lines?.[lineNum - 1] ?? 1,
      line: lineNum,
      color: (lineNum % 6) + 1, tone: (lineNum % 5) + 1, base: (lineNum % 4) + 1,
      bigram1: event.fromFuxi & 0b11, bigram2: (event.fromFuxi >> 2) & 0b11,
      fromName: fromHex?.name, toName: toHex?.name,
    };

    this.generatedByLevel[level]++;
    const code = template(ctx);

    // Actually execute the generated code and produce a real, level-
    // appropriate liveResult -- this is the part that was previously
    // fixed/templated in the simple version of this class. Every branch
    // below is wrapped so a real failure reports its real error message
    // instead of being hidden.
    let liveResult;
    try {
      const retrieveName = this.retrievalName(ctx.toolName, level);
      const built = new Function('__BrowserEventEmitter', code + `\nreturn ${retrieveName};`)(BrowserEventEmitter);
      if (level === 0 || level === 5) {
        liveResult = built; // plain object/data
      } else if (level === 1) {
        liveResult = built(Math.random());
      } else if (level === 2) {
        liveResult = built([{ isYang: 1, color: ctx.color, tone: ctx.tone }, { isYang: 0, color: 1, tone: 1 }]);
      } else if (level === 3) {
        liveResult = built([Math.random(), Math.random()], [Math.random(), Math.random()]);
      } else if (level === 4) {
        const inst = new built();
        inst.learn([ctx.fromName || 'seed', ctx.toName || 'target']);
        liveResult = inst.generate();
      } else if (level === 6) {
        const inst = new built();
        liveResult = inst.learn(`${ctx.fromName || ''} connects toward ${ctx.toName || ''}`);
      } else if (level === 7) {
        const inst = new built();
        inst.learn(`${ctx.fromName || 'gate'} moves through ${ctx.toName || 'gate'} via changing line ${lineNum}`);
        liveResult = inst.generate();
      }
    } catch (e) {
      liveResult = { error: e.message };
    }

    return {
      id: (crypto.randomUUID ? crypto.randomUUID() : Date.now().toString(36)),
      name: ctx.toolName,
      level, levelName: TF_LEVELS[level]?.name || 'Unknown',
      address: ctx.address,
      code,
      liveResult,
    };
  }

  getStats() {
    return { generatedByLevel: this.generatedByLevel.map((count, i) => ({ level: i, name: TF_LEVELS[i].name, count })),
             total: this.generatedByLevel.reduce((a, b) => a + b, 0) };
  }
}

// ══════════════════════════════════════════════════════════════════════
// REAL STATE-SPACE ENGINE
// Ported from mesh/src/core/{HexagramNode,StateSpaceLayer,ChangingLineEngine,
// StateSpaceModel}.js and mesh/src/core/layers/*.js in synthia-substrate.
// Module syntax stripped, same as the ToolFactory port above. This is what
// was previously only reachable by running two servers (Node mesh +
// Python AION) -- here it runs entirely in this tab.
//
// One deliberate simplification, disclosed rather than silently done:
// the real engine's tool-generation step normally goes through AutoLing
// (Klein's language-learning engine, ~700 more lines + 3 more modules
// this file does not include). That's genuinely a separate, bigger next
// piece -- not ported here. Instead, real changing-line events are handed
// straight to the ToolFactory already defined above, which expects
// exactly this event shape ({fromFuxi, toFuxi, changingLines:[{lineNumber}]})
// and needs no adapter.
//
// Also dropped: OntologicalAddress.js (planetary/zodiac addressing). It
// was imported by the original HexagramNode.js but never actually used
// in its class body -- a dead import in the source -- so nothing is lost
// by leaving it out.
// ══════════════════════════════════════════════════════════════════════
const CHANGING_THRESHOLD = 0.85;
const TENSION_DECAY = 0.95;

