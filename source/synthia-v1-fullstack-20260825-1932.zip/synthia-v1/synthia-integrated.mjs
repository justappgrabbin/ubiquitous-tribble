/**
 * Synthia integrated first-version organism slice.
 *
 * Wires:
 *   ingest → address (locked schema) → Design-conditioned identity
 *   → Tool-stable path (same person + same content → same tool)
 *   → ports: sleep, allostasis, ToM, Dunbar (from one-sim)
 *   → alters (from alters-lab)
 *   → AutoNova organ (from automaton model)
 *
 * Sub-base (degree/minute/second/arc) never public.
 * Gate mesh = latent weak link.
 *
 * Pure JS. No backend required for this loop.
 */

import { ingest, toCanonical, addressFromContent } from './synthia-ingest-address-run.mjs';
import { createSleepState, tickSleep } from './ports/sleep.mjs';
import { createAllostasisState, tickAllostasis } from './ports/allostasis.mjs';
import { createBeliefStore, applyPerceptions } from './ports/tom.mjs';
import { createSocialGraph, upsertContact, layerCounts, weakTieBridges } from './ports/dunbar.mjs';
import { createAlter, publicView, realityDrift, snapshotAlter, meshGateKey, samePositionKey } from './ports/alters.mjs';
import { createAutoNovaFromAddress } from './organs/autonova.mjs';
import { generateFromAddress, isToolFactoryReady } from './ports/toolfactory-bridge.mjs';
import { completeAnalogy, toBitString } from './boolean-ato.mjs';

/**
 * Person Design object (public layers + optional private sub-base).
 * Private fields are stored but never exported by publicView.
 */
export function makeDesign({
  planetary = 'Sun',
  dimension = 'Design',
  gate = 20,
  line = 3,
  color = 2,
  tone = 1,
  base = 4,
  degree = null,
  minute = null,
  second = null,
  arc = null,
  zodiac = 1,
  house = 1,
  chronotype = 0,
} = {}) {
  return {
    planetary,
    dimension,
    gate,
    line,
    color,
    tone,
    base,
    degree,
    minute,
    second,
    arc,
    zodiac,
    house,
    chronotype,
    // public key used for tool identity (excludes sub-base)
    addressKey: [
      planetary, dimension, gate, line, color, tone, base, zodiac, house,
    ].join('|'),
  };
}

/**
 * Build a full person-bound organism slice.
 * Same Design → same tools / same AutoNova / same alter identity.
 */
export function createPersonSlice(design) {
  const alter = createAlter(design);
  const sleep = createSleepState(design);
  const allo = createAllostasisState(design);
  const beliefs = createBeliefStore(design);
  const social = createSocialGraph(design);

  return {
    design,
    alter,
    sleep,
    allo,
    beliefs,
    social,
    tools: new Map(), // contentKey → tool artifact (stable identity)
  };
}

/**
 * Content key for tool identity: hash of content (stable).
 */
function contentKey(content) {
  const s = typeof content === 'string' ? content : JSON.stringify(content);
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return (h >>> 0).toString(16);
}

/**
 * Ingest under person Design.
 * Rule: same Design + same content → same tool (cached).
 */
export function personIngest(slice, content, opts = {}) {
  const cKey = contentKey(content);
  const toolId = `${slice.design.addressKey}::${cKey}`;

  if (slice.tools.has(toolId) && !opts.forceNew) {
    return { tool: slice.tools.get(toolId), reused: true, toolId };
  }

  // Design bias makes address person-unique
  const result = ingest(content, {
    name: opts.name,
    designBias: {
      gate: slice.design.gate - 1,
      line: slice.design.line - 1,
      color: slice.design.color - 1,
      tone: slice.design.tone - 1,
      base: slice.design.base - 1,
      dimension: ['Movement', 'Evolution', 'Being', 'Design', 'Space'].indexOf(slice.design.dimension),
    },
    kindHint: opts.kindHint,
  });

  // AutoNova bound to this address
  const nova = createAutoNovaFromAddress(result.address, {
    duration: opts.duration ?? 5,
  });

  // Real ToolFactory generation (person + address conditioned)
  const factoryOut = generateFromAddress(result.address, {
    lineNumber: result.address.line || slice.design.line || 1,
  });

  const tool = Object.freeze({
    toolId,
    designKey: slice.design.addressKey,
    contentKey: cKey,
    address: result.address,
    quality: result.quality,
    primitive: result.primitive,
    artifact: result.artifact,
    autonova: nova,
    factory: factoryOut,
    run: (input) => result.run(input),
    sampleMotion: (t) => nova.sample(t),
    sequence: (frames) => nova.sequence(frames),
    /** Video-oriented frame list: time + channel values + optional canvas hint */
    videoFrames: (frameCount = 24, width = 320, height = 180) => {
      const seq = nova.sequence(frameCount);
      return seq.map((f, i) => ({
        index: i,
        time: f.time,
        intensity: f.intensity,
        phase: f.phase,
        motion: f.motion,
        // procedural pixel hint for Media organ / canvas (no external encoder required)
        rgb: {
          r: Math.round(40 + 180 * f.intensity),
          g: Math.round(30 + 120 * f.phase),
          b: Math.round(60 + 160 * f.motion),
        },
        width,
        height,
        designKey: f.designKey,
        gate: f.gate,
      }));
    },
  });

  slice.tools.set(toolId, tool);
  return { tool, reused: false, toolId };
}

/**
 * Tick embodied state (sleep + allostasis).
 */
export function tickEmbodied(slice, { stress = 0, dtMinutes = 15 } = {}) {
  slice.sleep = tickSleep(slice.sleep, dtMinutes);
  slice.allo = tickAllostasis(slice.allo, stress, dtMinutes);
  return {
    sleep: {
      S: slice.sleep.S,
      C: slice.sleep.C,
      asleep: slice.sleep.asleep,
      grogginess: slice.sleep.grogginess,
      minuteOfDay: slice.sleep.minuteOfDay,
    },
    allo: {
      load: slice.allo.load,
      risk: slice.allo.risk,
      band: slice.allo.band,
    },
  };
}

/**
 * Mesh identity for this person (public gate only — weak link).
 */
export function meshIdentity(slice) {
  return {
    gateKey: meshGateKey(slice.alter),
    publicAddress: publicView(slice.alter).publicAddress,
    // same-position key is NOT public; only for authorized same-position share
    _samePositionKey: samePositionKey(slice.alter),
  };
}

// ─── Self-test ───
const isMain = process.argv[1] && process.argv[1].endsWith('synthia-integrated.mjs');
if (isMain) {
  console.log('=== Synthia integrated — person-unique tools + ports + AutoNova ===\n');

  const designA = makeDesign({ gate: 20, line: 3, dimension: 'Design', chronotype: 0.4 });
  const designB = makeDesign({ gate: 61, line: 1, dimension: 'Movement', chronotype: -0.3 });

  const personA = createPersonSlice(designA);
  const personB = createPersonSlice(designB);

  const content = 'The environment holds energy near creation and seeing.';

  const a1 = personIngest(personA, content, { name: 'field-sentence' });
  const a2 = personIngest(personA, content, { name: 'field-sentence' });
  const b1 = personIngest(personB, content, { name: 'field-sentence' });

  console.log('IDENTITY RULE');
  console.log('  A same content twice → same tool?', a1.toolId === a2.toolId, '(reused:', a2.reused, ')');
  console.log('  A vs B same content → different tool?', a1.toolId !== b1.toolId);
  console.log('  A address:', a1.tool.address.key);
  console.log('  B address:', b1.tool.address.key);

  console.log('\nTOOLFACTORY ready?', isToolFactoryReady());
  if (a1.tool.factory?.generated) {
    const g = a1.tool.factory.generated;
    console.log('  generated:', g.name, '| level', g.level, g.levelName);
    console.log('  liveResult:', JSON.stringify(g.liveResult).slice(0, 120));
  } else {
    console.log('  factory:', a1.tool.factory?.error || a1.tool.factory);
  }

  console.log('\nAUTONOVA + VIDEO FRAMES (person A)');
  const frames = a1.tool.sequence(5);
  frames.forEach((f, i) => {
    console.log(`  frame ${i}: t=${f.time.toFixed(2)} intensity=${f.intensity.toFixed(3)} phase=${f.phase.toFixed(3)} motion=${f.motion.toFixed(3)}`);
  });
  const video = a1.tool.videoFrames(4, 160, 90);
  console.log('  videoFrames[0]:', video[0]);
  console.log('  videoFrames count:', video.length);

  console.log('\nEMBODIED TICK (A)');
  const emb = tickEmbodied(personA, { stress: 0.4, dtMinutes: 30 });
  console.log('  sleep:', emb.sleep);
  console.log('  allo:', emb.allo);

  console.log('\nTOM + DUNBAR (A)');
  applyPerceptions(personA.beliefs, [
    { mid: 'devi', name: 'Devi', node: 'cafe', nodeName: 'Café', mood: 0.3, tick: 1, day: 1 },
  ]);
  applyPerceptions(personA.beliefs, [
    { mid: 'devi', name: 'Devi', node: 'office', nodeName: 'Office', mood: -0.1, tick: 2, day: 1 },
  ]);
  console.log('  belief Devi:', personA.beliefs.beliefs['devi']);
  upsertContact(personA.social, 'devi', 'Devi', 0.9, 1);
  upsertContact(personA.social, 'kai', 'Kai', 0.5, 1);
  console.log('  layers:', layerCounts(personA.social));

  console.log('\nALTER / MESH (A)');
  const mesh = meshIdentity(personA);
  console.log('  gateKey (public mesh):', mesh.gateKey);
  console.log('  public address:', mesh.publicAddress);
  console.log('  private samePosition present?', !!mesh._samePositionKey);

  const drift = realityDrift(personA.alter, {
    execution_discipline: 4,
    exploration_freedom: 3,
    life_state_match: 4,
    energy_level: 2,
  });
  console.log('  reality drift:', drift.toFixed(3));

  console.log('\nATO between A and B gate vectors');
  const rel = completeAnalogy(
    a1.tool.primitive.gateVector,
    b1.tool.primitive.gateVector,
    a1.tool.primitive.gateVector,
    'equivalence'
  );
  console.log('  relation:', toBitString(rel.relation), 'result:', toBitString(rel.result));

  (async () => {
    // 2) Mount onto minimal Adaya-style host
    const { mountOnHost, createMinimalHost } = await import('./organs/adaya-mount.mjs');
    const host = createMinimalHost();
    const { pack } = mountOnHost(host, { gate: 20, line: 3, dimension: 'Design' }, 'synthiaV1');
    console.log('\nADAYA MOUNT');
    console.log('  host.organs.synthiaV1?', !!host.organs.synthiaV1);
    console.log('  processFabric:', host.processFabric);
    const mountedIngest = pack.ingest('mount test content', { name: 'mount-demo' });
    console.log('  mounted tool factory level:', mountedIngest.tool.factory?.generated?.levelName);

    // 3) Video frame buffers + PPM sequence
    const { writePPMSequence } = await import('./organs/video-frames.mjs');
    const vframes = a1.tool.videoFrames(6, 64, 36);
    const paths = await writePPMSequence(vframes, new URL('./artifacts-video', import.meta.url).pathname, 'nova');
    console.log('\nVIDEO FRAMES');
    console.log('  wrote', paths.length, 'PPM frames');
    console.log('  first:', paths[0]);

    console.log('\n=== all 3 complete: ToolFactory + Adaya mount + video frames ===');
  })().catch((e) => {
    console.error(e);
    process.exit(1);
  });
}
