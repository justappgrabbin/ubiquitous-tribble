/* Synthia residence service worker — generated */
const CACHE = 'synthia-v1-residence';
const ASSETS = ['./phone-shell.html', './synthia-bundle.js'];
self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(ASSETS).catch(() => {})));
  self.skipWaiting();
});
self.addEventListener('activate', (e) => {
  e.waitUntil(self.clients.claim());
});
self.addEventListener('fetch', (e) => {
  e.respondWith(
    caches.match(e.request).then((r) => r || fetch(e.request).catch(() => caches.match('./phone-shell.html')))
  );
});
