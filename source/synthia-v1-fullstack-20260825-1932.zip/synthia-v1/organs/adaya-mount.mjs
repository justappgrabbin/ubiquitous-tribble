/**
 * Mount bridge: attach the synthia-v1 person slice (ports + AutoNova + ToolFactory)
 * onto an Adaya / SynthiaUnit-style organism without replacing its invariants.
 *
 * Expects a host with optional:
 *   host.organs / host.registerOrgan / host.processFabric
 * Falls back to a plain registry if the full organism is not present.
 */

import {
  makeDesign,
  createPersonSlice,
  personIngest,
  tickEmbodied,
  meshIdentity,
} from '../synthia-integrated.mjs';

/**
 * Create a mountable organ pack bound to a Design.
 */
export function createOrganPack(designSpec = {}) {
  const design = makeDesign(designSpec);
  const slice = createPersonSlice(design);

  return {
    id: `organ-pack:${design.addressKey}`,
    design,
    slice,
    /** Ingest content under this person's Design → stable tool + factory + AutoNova */
    ingest(content, opts) {
      return personIngest(slice, content, opts);
    },
    tick(opts) {
      return tickEmbodied(slice, opts);
    },
    mesh() {
      return meshIdentity(slice);
    },
    listTools() {
      return [...slice.tools.keys()];
    },
    getTool(toolId) {
      return slice.tools.get(toolId) || null;
    },
  };
}

/**
 * Attach organ pack to a host organism.
 * Returns the same host for chaining.
 */
export function mountOnHost(host, designSpec = {}, organName = 'synthiaV1') {
  const pack = createOrganPack(designSpec);

  if (!host) {
    return { host: { organs: { [organName]: pack } }, pack };
  }

  // Prefer explicit register API if present (Adaya style)
  if (typeof host.registerOrgan === 'function') {
    host.registerOrgan(organName, pack);
  } else if (host.organs && typeof host.organs === 'object') {
    host.organs[organName] = pack;
  } else {
    host.organs = { ...(host.organs || {}), [organName]: pack };
  }

  // Optional process-fabric style reachability flag
  if (host.processFabric && typeof host.processFabric === 'object') {
    host.processFabric[organName] = { mounted: true, designKey: pack.design.addressKey };
  }

  // Surface convenience on host
  host.synthiaV1 = pack;

  return { host, pack };
}

/**
 * Minimal host stand-in when full Adaya package is not loaded in this process.
 */
export function createMinimalHost() {
  return {
    organs: {},
    processFabric: {},
    registerOrgan(name, organ) {
      this.organs[name] = organ;
    },
  };
}
