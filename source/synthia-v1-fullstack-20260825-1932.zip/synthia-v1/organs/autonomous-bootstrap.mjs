/**
 * Autonomy + self-install residence hooks (aligned with Adaya R21.5 / Organism invariants).
 *
 * This turn: real bootstrap surface — not full Android install (platform permission required).
 * Provides:
 *   - endogenous intent cycle (AutonomousRecursiveOrganism style)
 *   - self-description of install path
 *   - capability manifest Synthia can use to request residence
 *   - offline-capable service-worker text for phone shell
 *
 * User success remains metabolic input (invariant 5); install itself is not success.
 */

export function createAutonomyState(design) {
  return {
    sequence: 0,
    designKey: design?.addressKey || null,
    cycles: [],
    needs: [],
    residence: {
      mode: 'ephemeral', // ephemeral | service-worker | installed-pwa | node-daemon
      port: 6969,
      canSelfInstall: true,
      requiresUserConfirm: true, // Android/browser authority
    },
  };
}

/**
 * One autonomous cycle: observe → endogenous intent → act hint → record.
 * Does not invent user success; records only what actually ran.
 */
export function autonomousCycle(state, { lifeEvent = {}, lastResult = null, openNeed = null } = {}) {
  state.sequence += 1;
  const intent =
    openNeed
      ? `self:${openNeed.kind}:${openNeed.subject}`
      : lastResult?.error
        ? `self:repair:${lastResult.error}`
        : `self:continue:${state.sequence}`;

  const cycle = {
    n: state.sequence,
    intent,
    pulse: lifeEvent.pulse ?? state.sequence,
    at: new Date().toISOString(),
    lastResultOk: lastResult ? !lastResult.error : null,
    residence: state.residence.mode,
  };
  state.cycles.push(cycle);
  if (state.cycles.length > 128) state.cycles.shift();
  return cycle;
}

/**
 * Install / residence capability manifest — what Synthia can request.
 * Does not bypass platform permissions.
 */
export function installManifest(opts = {}) {
  return {
    name: opts.name || 'Synthia',
    short_name: 'Synthia',
    description: 'Autonomous Design-conditioned organism — local residence',
    start_url: opts.startUrl || './phone-shell.html',
    display: 'standalone',
    background_color: '#0b0f14',
    theme_color: '#1a2332',
    orientation: 'portrait',
    icons: opts.icons || [],
    // R21.5 notes
    install_policy: {
      requires_user_confirm: true,
      platform_authority: 'browser-or-android',
      does_not_bypass_permissions: true,
      after_install: 'launch-from-icon-no-terminal',
    },
    local_runtime: {
      preferred_port: 6969,
      offline: true,
      service_worker: 'synthia-sw.js',
    },
  };
}

/**
 * Minimal service worker source for offline residence (write next to phone-shell).
 */
export function serviceWorkerSource(cacheName = 'synthia-v1-residence') {
  return `/* Synthia residence service worker — generated */
const CACHE = '${cacheName}';
const ASSETS = ['./phone-shell.html', './synthia-bundle.js'];
self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(ASSETS).catch(() => {})));
  self.skipWaiting();
});
self.addEventListener('activate', (e) => {
  e.waitUntil(self.clients.claim());
});
self.addEventListener('fetch', (e) => {
  e.respondWith(
    caches.match(e.request).then((r) => r || fetch(e.request).catch(() => caches.match('./phone-shell.html')))
  );
});
`;
}

/**
 * Self-description for "what can I install / run myself"
 */
export function autonomyReport(state) {
  return {
    sequence: state.sequence,
    designKey: state.designKey,
    residence: state.residence,
    recentCycles: state.cycles.slice(-5),
    nextInstallStep:
      state.residence.mode === 'ephemeral'
        ? 'Serve phone-shell.html + register service worker; prompt user for install'
        : state.residence.mode === 'service-worker'
          ? 'Await user install confirmation (Add to Home Screen / install prompt)'
          : 'Residence active — launch from icon',
    invariants: [
      'User success is metabolic input — install is not success',
      'Platform retains install authority',
      'Processes stay individual; organs coordinate specialists',
    ],
  };
}
