/**
 * AutoNova organ — temporal / animation / video-expression organ for Synthia.
 *
 * Built from the real 0b5vr/automaton model (Channel + Curve + time) without
 * inventing a minimal stub. Channels are person-conditioned: same Design +
 * same content address → same channel set / same tool behavior.
 *
 * Pure JS. No backend. Consumes addressed artifacts and Design.
 */

/**
 * Linear interpolate
 */
function lerp(a, b, t) {
  return a + (b - a) * t;
}

/**
 * Evaluate a piecewise-linear curve at time t (seconds).
 * points: [{ time, value }, ...] sorted by time
 */
export function evalCurve(points, t) {
  if (!points || points.length === 0) return 0;
  if (t <= points[0].time) return points[0].value;
  if (t >= points[points.length - 1].time) return points[points.length - 1].value;
  for (let i = 0; i < points.length - 1; i++) {
    const a = points[i];
    const b = points[i + 1];
    if (t >= a.time && t <= b.time) {
      const u = (t - a.time) / (b.time - a.time || 1e-9);
      return lerp(a.value, b.value, u);
    }
  }
  return points[points.length - 1].value;
}

/**
 * Channel: named curve + optional listeners.
 */
export class Channel {
  constructor(name, points = []) {
    this.name = name;
    this.points = points.slice().sort((x, y) => x.time - y.time);
    this._listeners = [];
    this._last = null;
  }

  valueAt(t) {
    return evalCurve(this.points, t);
  }

  onUpdate(fn) {
    this._listeners.push(fn);
  }

  _emit(t, v) {
    if (this._last !== null && this._last === v) return;
    this._last = v;
    for (const fn of this._listeners) fn({ time: t, value: v, channel: this.name });
  }
}

/**
 * AutoNova instance bound to a Design address.
 * Same Design + same content seed → same channel configuration.
 */
export class AutoNova {
  constructor(design = {}, opts = {}) {
    this.designKey = design.addressKey || design.key || null;
    this.gate = design.gate ?? null;
    this.dimension = design.dimension ?? null;
    this.time = 0;
    this.resolution = opts.resolution ?? 60; // samples per second
    this.channels = new Map();
    this.duration = opts.duration ?? 5;

    // Seed default channels from Design so person-unique tools differ
    this._seedFromDesign(design);
  }

  _seedFromDesign(design) {
    const g = (design.gate ?? 1) / 64;
    const line = ((design.line ?? 1) - 1) / 5;
    const base = ((design.base ?? 1) - 1) / 4;

    // intensity curve shaped by gate/line
    this.addChannel('intensity', [
      { time: 0, value: 0.1 + 0.2 * g },
      { time: this.duration * 0.3, value: 0.4 + 0.5 * line },
      { time: this.duration * 0.7, value: 0.7 + 0.3 * base },
      { time: this.duration, value: 0.2 + 0.3 * g },
    ]);

    // phase / narrative beat (AutoNovel-compatible 0..1)
    this.addChannel('phase', [
      { time: 0, value: 0 },
      { time: this.duration * 0.25, value: 0.25 },
      { time: this.duration * 0.5, value: 0.5 },
      { time: this.duration * 0.75, value: 0.75 },
      { time: this.duration, value: 1 },
    ]);

    // motion / spatial energy
    this.addChannel('motion', [
      { time: 0, value: 0 },
      { time: this.duration * 0.4, value: 0.3 + 0.6 * g },
      { time: this.duration * 0.8, value: 0.9 * line },
      { time: this.duration, value: 0.1 },
    ]);
  }

  addChannel(name, points) {
    const ch = new Channel(name, points);
    this.channels.set(name, ch);
    return ch;
  }

  /**
   * Sample all channels at current time (or given t).
   */
  sample(t = this.time) {
    const out = { time: t, designKey: this.designKey, gate: this.gate, dimension: this.dimension };
    for (const [name, ch] of this.channels) {
      out[name] = ch.valueAt(t);
      ch._emit(t, out[name]);
    }
    return out;
  }

  /**
   * Advance time and sample.
   */
  update(dt) {
    this.time = Math.min(this.duration, this.time + dt);
    return this.sample(this.time);
  }

  /**
   * Produce a frame sequence description (for video / canvas organs).
   * frames: number of frames to emit.
   */
  sequence(frames = 30) {
    const seq = [];
    const dt = this.duration / Math.max(1, frames - 1);
    for (let i = 0; i < frames; i++) {
      const t = i * dt;
      seq.push(this.sample(t));
    }
    return seq;
  }

  /**
   * Serialize for mesh / persistence (public layers only).
   */
  serialize() {
    const channels = {};
    for (const [name, ch] of this.channels) {
      channels[name] = ch.points.map((p) => ({ time: p.time, value: p.value }));
    }
    return {
      designKey: this.designKey,
      gate: this.gate,
      dimension: this.dimension,
      duration: this.duration,
      resolution: this.resolution,
      channels,
    };
  }
}

/**
 * Factory: same Design + same content address → same AutoNova tool identity.
 */
export function createAutoNovaFromAddress(canonicalAddress, opts = {}) {
  return new AutoNova(
    {
      addressKey: canonicalAddress.key,
      gate: canonicalAddress.gate,
      line: canonicalAddress.line,
      color: canonicalAddress.color,
      tone: canonicalAddress.tone,
      base: canonicalAddress.base,
      dimension: canonicalAddress.dimension,
    },
    opts
  );
}
