/**
 * Video-frame output from AutoNova sequences.
 * Pure JS — produces frame descriptors and optional PPM/binary RGB buffers
 * that a Media organ or browser canvas can consume. No external encoder required.
 */

/**
 * Expand videoFrames() output into raw RGB buffers (Uint8ClampedArray per frame).
 * Each buffer is width * height * 4 (RGBA).
 */
export function framesToRGBA(videoFrames) {
  return videoFrames.map((f) => {
    const { width, height, rgb, intensity = 0.5, motion = 0.5, phase = 0.5 } = f;
    const buf = new Uint8ClampedArray(width * height * 4);
    const cx = width / 2;
    const cy = height / 2;
    const radius = Math.min(width, height) * (0.15 + 0.35 * intensity);

    for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
        const i = (y * width + x) * 4;
        const dx = x - cx;
        const dy = y - cy;
        const dist = Math.sqrt(dx * dx + dy * dy);
        // motion shifts a soft blob; phase rotates accent
        const angle = Math.atan2(dy, dx) + phase * Math.PI * 2;
        const pulse = Math.max(0, 1 - dist / (radius * (1 + 0.5 * motion)));
        const accent = 0.5 + 0.5 * Math.cos(angle);

        buf[i] = Math.min(255, Math.round(rgb.r * pulse + 20 * accent));
        buf[i + 1] = Math.min(255, Math.round(rgb.g * pulse + 15 * (1 - accent)));
        buf[i + 2] = Math.min(255, Math.round(rgb.b * pulse));
        buf[i + 3] = 255;
      }
    }
    return { ...f, rgba: buf };
  });
}

/**
 * Encode a single frame as PPM (P6) binary string header + raw RGB (no alpha).
 * Useful for file drop / debug without a full video codec.
 */
export function frameToPPM(frameWithRgba) {
  const { width, height, rgba } = frameWithRgba;
  const header = `P6\n${width} ${height}\n255\n`;
  const rgb = Buffer.alloc(width * height * 3);
  for (let p = 0, q = 0; p < rgba.length; p += 4, q += 3) {
    rgb[q] = rgba[p];
    rgb[q + 1] = rgba[p + 1];
    rgb[q + 2] = rgba[p + 2];
  }
  return Buffer.concat([Buffer.from(header, 'ascii'), rgb]);
}

/**
 * Write a sequence of PPM frames to a directory (Node).
 */
export async function writePPMSequence(videoFrames, dir, prefix = 'frame') {
  const { mkdir, writeFile } = await import('fs/promises');
  const { join } = await import('path');
  await mkdir(dir, { recursive: true });
  const rgbaFrames = framesToRGBA(videoFrames);
  const paths = [];
  for (let i = 0; i < rgbaFrames.length; i++) {
    const ppm = frameToPPM(rgbaFrames[i]);
    const path = join(dir, `${prefix}-${String(i).padStart(4, '0')}.ppm`);
    await writeFile(path, ppm);
    paths.push(path);
  }
  return paths;
}
