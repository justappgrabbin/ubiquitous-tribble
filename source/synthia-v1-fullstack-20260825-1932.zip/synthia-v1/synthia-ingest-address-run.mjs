/**
 * Synthia v1 core loop — pure JS, no backend
 *
 * Goal (acceptance):
 *   ingest anything → address it in the real system scheme →
 *   quality-attribute it → reduce to smallest viable primitive →
 *   run / compute at that level → scale back up.
 *
 * Addressing is the existing Synthia micro/macro scheme:
 *   Micro:  gate(0-63) × line(0-5) × color(0-5) × tone(0-5) × base(0-4)
 *   Macro:  planet × dimension × zodiac × house
 *   Dimensions: Movement | Evolution | Being | Design | Space
 *
 * This file is intentionally small and fully wired.
 * It uses the real boolean-ato primitives and the real hexagram / ToolFactory
 * substrate already present in the project.
 */

import {
  completeAnalogy,
  toBitString,
  normalizeVector,
  equivalence,
  xor,
} from './boolean-ato.mjs';

// ─── Real dimension / interrogative map (from five_dimensions + address bridge) ───
export const DIMENSIONS = Object.freeze([
  { id: 0, name: 'Movement', interrogative: 'WHERE', baseLabel: 'Individuality', sense: 'Seeing' },
  { id: 1, name: 'Evolution', interrogative: 'WHAT',  baseLabel: 'Mind',          sense: 'Taste'  },
  { id: 2, name: 'Being',     interrogative: 'WHEN',  baseLabel: 'Body',          sense: 'Touch'  },
  { id: 3, name: 'Design',    interrogative: 'WHY',   baseLabel: 'Ego',           sense: 'Smell'  },
  { id: 4, name: 'Space',     interrogative: 'WHO',   baseLabel: 'Personality',   sense: 'Hearing'},
]);

const PLANET_NAMES = Object.freeze([
  'Sun','Earth','Moon','North Node','South Node','Mercury','Venus',
  'Mars','Jupiter','Saturn','Uranus','Neptune','Pluto',
]);

// ─── Address normalization (matches core/address-adapter + synthia-bridge) ───
function clamp(n, min, max, fallback = min) {
  const v = Number(n);
  if (!Number.isFinite(v)) return fallback;
  return Math.max(min, Math.min(max, Math.trunc(v)));
}

export function normalizeMicro(addr = {}) {
  return Object.freeze({
    gate:  clamp(addr.gate,  0, 63, 0),
    line:  clamp(addr.line,  0, 5,  0),
    color: clamp(addr.color, 0, 5,  0),
    tone:  clamp(addr.tone,  0, 5,  0),
    base:  clamp(addr.base,  0, 4,  0),
  });
}

export function normalizeMacro(addr = {}, fallbackDimension = 0) {
  return Object.freeze({
    planet:    clamp(addr.planet,    0, 12, 0),
    dimension: clamp(addr.dimension, 0, 4,  fallbackDimension),
    zodiac:    clamp(addr.zodiac,    0, 11, 0),
    house:     clamp(addr.house,     0, 11, 0),
  });
}

/** Human-readable + machine key for a full address */
export function toCanonical(address) {
  const micro = normalizeMicro(address?.micro || address);
  const macro = normalizeMacro(address?.macro || address, micro.base);
  const dim = DIMENSIONS[macro.dimension];
  return Object.freeze({
    mode: 'micro',
    planetary: PLANET_NAMES[macro.planet] || String(macro.planet),
    dimension: dim.name,
    dimensionId: macro.dimension,
    interrogative: dim.interrogative,
    gate: micro.gate + 1,   // 1-64 display
    line: micro.line + 1,   // 1-6
    color: micro.color + 1,
    tone: micro.tone + 1,
    base: micro.base + 1,   // 1-5
    zodiac: macro.zodiac + 1,
    house: macro.house + 1,
    // compact index for reduction (0 .. 69119)
    microIndex: micro.gate + (micro.line << 6) + (micro.color << 9) + (micro.tone << 12) + (micro.base << 15),
    key: [
      `planet=${PLANET_NAMES[macro.planet] || macro.planet}`,
      `dim=${dim.name}`,
      `gate=${micro.gate + 1}`,
      `line=${micro.line + 1}`,
      `color=${micro.color + 1}`,
      `tone=${micro.tone + 1}`,
      `base=${micro.base + 1}`,
    ].join('|'),
  });
}

// ─── Content fingerprint → deterministic address seed ───
function fingerprint(content) {
  const s = typeof content === 'string' ? content : JSON.stringify(content);
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

/**
 * Derive a micro address from content + optional design bias.
 * designBias: optional { gate?, line?, color?, tone?, base?, dimension? }
 * so tools become person-unique when a Design is present.
 */
export function addressFromContent(content, designBias = null) {
  const h = fingerprint(content);
  const micro = {
    gate:  (h)        & 63,
    line:  (h >>> 6)  & 5,
    color: (h >>> 9)  & 5,
    tone:  (h >>> 12) & 5,
    base:  (h >>> 15) & 4,
  };
  // If a human Design is supplied, blend (not overwrite) so the address
  // stays content-grounded but person-conditioned.
  if (designBias) {
    if (designBias.gate  != null) micro.gate  = (micro.gate  + clamp(designBias.gate,  0, 63)) % 64;
    if (designBias.line  != null) micro.line  = (micro.line  + clamp(designBias.line,  0, 5))  % 6;
    if (designBias.color != null) micro.color = (micro.color + clamp(designBias.color, 0, 5))  % 6;
    if (designBias.tone  != null) micro.tone  = (micro.tone  + clamp(designBias.tone,  0, 5))  % 6;
    if (designBias.base  != null) micro.base  = (micro.base  + clamp(designBias.base,  0, 4))  % 5;
  }
  const dimension = designBias?.dimension != null
    ? clamp(designBias.dimension, 0, 4)
    : micro.base;
  const macro = {
    planet: (h >>> 18) % 13,
    dimension,
    zodiac: (h >>> 22) % 12,
    house:  (h >>> 26) % 12,
  };
  return { micro: normalizeMicro(micro), macro: normalizeMacro(macro, dimension) };
}

// ─── Quality attribution (lightweight, pure) ───
export function qualityOf(content, kindHint = null) {
  const s = typeof content === 'string' ? content : JSON.stringify(content);
  const len = s.length;
  const hasCode = /function|class|=>|export|import|const |let |var /.test(s);
  const hasJson = /^\s*[\[{]/.test(s.trim());
  const hasBinaryHint = /[\x00-\x08\x0e-\x1f]/.test(s.slice(0, 200));
  let kind = kindHint || 'text';
  if (hasCode) kind = 'code';
  else if (hasJson) kind = 'data';
  else if (hasBinaryHint) kind = 'binary';
  // crude viability score: structure + length balance
  const structure = (hasCode ? 0.4 : 0) + (hasJson ? 0.2 : 0) + (len > 32 ? 0.2 : 0) + (len < 200_000 ? 0.2 : 0);
  return Object.freeze({
    kind,
    length: len,
    viability: Math.max(0, Math.min(1, structure)),
    runnableHint: kind === 'code' || kind === 'data',
  });
}

// ─── Primitive reduction ───
/**
 * Reduce an addressed artifact to its smallest viable primitive.
 * For v1: the primitive is the (microIndex, dimension, kind, bitPattern).
 * The bitPattern is a 6-bit gate vector usable by boolean-ato.
 */
export function reduceToPrimitive(canonical, quality, content) {
  const gateBits = (canonical.gate - 1).toString(2).padStart(6, '0');
  const dimBits = canonical.dimensionId.toString(2).padStart(3, '0');
  return Object.freeze({
    addressKey: canonical.key,
    microIndex: canonical.microIndex,
    dimension: canonical.dimension,
    interrogative: canonical.interrogative,
    kind: quality.kind,
    viability: quality.viability,
    gateVector: gateBits,           // 6-bit, ATO-ready
    dimVector: dimBits,
    // smallest runnable unit: a pure function of the vectors
    compute: (otherGateVector = null) => {
      if (!otherGateVector) {
        return { value: gateBits, note: 'identity at this address' };
      }
      const rel = completeAnalogy(gateBits, otherGateVector, gateBits, 'equivalence');
      return {
        relation: toBitString(rel.relation),
        result: toBitString(rel.result),
        mode: rel.mode,
      };
    },
  });
}

// ─── Scale up: reconstitute a minimal runnable artifact ───
export function scaleUp(primitive, originalContent) {
  const runnable = {
    address: primitive.addressKey,
    dimension: primitive.dimension,
    kind: primitive.kind,
    // the artifact can always be "run" as: report its address + optional analogy
    run(input = null) {
      const out = {
        status: 'RUN',
        address: primitive.addressKey,
        dimension: primitive.dimension,
        interrogative: primitive.interrogative,
        viability: primitive.viability,
        primitiveResult: primitive.compute(input?.gateVector || null),
      };
      if (primitive.kind === 'code' && typeof originalContent === 'string') {
        // do not eval arbitrary code in this scaffold; only report readiness
        out.codeReady = true;
        out.note = 'code is addressed and quality-attributed; execution is gated by organ policy';
      }
      return Object.freeze(out);
    },
  };
  return Object.freeze(runnable);
}

// ─── Main ingest pipeline ───
/**
 * @param {string|object} content  - raw payload (text, code string, json, …)
 * @param {object} [opts]
 * @param {object} [opts.designBias] - human Design partial address (makes result person-unique)
 * @param {string} [opts.kindHint]
 * @param {string} [opts.name]
 */
export function ingest(content, opts = {}) {
  const quality = qualityOf(content, opts.kindHint);
  const rawAddress = addressFromContent(content, opts.designBias || null);
  const canonical = toCanonical(rawAddress);
  const primitive = reduceToPrimitive(canonical, quality, content);
  const artifact = scaleUp(primitive, content);

  return Object.freeze({
    name: opts.name || `artifact@${canonical.gate}.${canonical.line}`,
    quality,
    address: canonical,
    primitive,
    artifact,
    // convenience: run immediately
    run: (input) => artifact.run(input),
  });
}

// ─── Self-test when executed directly ───
const isMain = process.argv[1] && process.argv[1].endsWith('synthia-ingest-address-run.mjs');
if (isMain) {
  console.log('=== Synthia v1 — ingest → address → reduce → run ===\n');

  // 1. Plain text
  const t1 = ingest('The environment holds energy near creation and seeing.', { name: 'field-sentence' });
  console.log('TEXT');
  console.log('  address:', t1.address.key);
  console.log('  dim:', t1.address.dimension, t1.address.interrogative);
  console.log('  quality:', t1.quality);
  console.log('  run:', t1.run());

  // 2. Same text with a Design bias (different person → different address)
  const t2 = ingest('The environment holds energy near creation and seeing.', {
    name: 'field-sentence-design',
    designBias: { gate: 20, line: 3, dimension: 3 }, // Design / Why bias
  });
  console.log('\nSAME TEXT + DESIGN BIAS');
  console.log('  address:', t2.address.key);
  console.log('  different from plain?', t1.address.key !== t2.address.key);

  // 3. Code fragment
  const code = `
    function resonance(a, b) {
      return Math.abs(a - b) < 0.15;
    }
  `;
  const c1 = ingest(code, { name: 'resonance-fn', kindHint: 'code' });
  console.log('\nCODE');
  console.log('  address:', c1.address.key);
  console.log('  quality:', c1.quality);
  console.log('  run:', c1.run({ gateVector: '010101' }));

  // 4. Analogy between two addressed artifacts
  const a = t1.primitive.gateVector;
  const b = c1.primitive.gateVector;
  const analogy = completeAnalogy(a, b, a, 'equivalence');
  console.log('\nATO between text-gate and code-gate');
  console.log('  A:', a, 'B:', b);
  console.log('  relation:', toBitString(analogy.relation));
  console.log('  D (result):', toBitString(analogy.result));

  console.log('\n=== v1 core loop exercised ===');
}
